#ifndef OSURFACE_H_INCLUDED
#define OSURFACE_H_INCLUDED

/*
OBJET       classe d'une surface, tableau de pixels
            la surface est ensuite convertie en texture pour être affichée depuis une OImage

DATE        12/2017

AUTEUR      philippe Thebaud

COMMENTAIRE les images sont adaptées à openGL : mode rgb(a) et flipV si necessaire
			! non terminé > les surfaces ne sont pas bloquées
*/

#include <GL/glew.h>
#include <string>
#include "string.h" // memcpy

#include "OUtils.h"
#include "bmpCodec/loaderBMP.h"
#include "bmpCodec/lodepng.h"
#include "bmpCodec/jpgd.h"



class OSurface
{
public:
    OSurface();
    OSurface(const OSurface &copy);
    ~OSurface();

    OSurface &operator = (const OSurface &surface);

	void		blit(ORect_i& srcRect, OSurface& dstSurface, ORect_i& dstRect);
	void        boxFillS(ORect_i& dstRect, uint32_t color);
	void        boxFrameS(ORect_i& dstRect, uint32_t color);

    void 		create(int width, int height, int byteperpixel, int format);
    void 		clear();
    void		copy(int width, int height, int byteperpixel, void* pixels);

	bool        exist() const;

    void		fill(uint32_t color);

    void		flipV();

    inline int      getBpp() const { return m_bpp; }
    inline int      getFormat() const { return m_format; }
    inline int      getHeight() const { return m_height; }
    inline int      getPitch() const { return m_pitch; }
    inline uint8_t* getPixels() const {return m_pixels; }
    inline int      getWidth() const { return m_width; }
    uint32_t 		getPixel(int x, int y) const;
    void            getPixel_RGBA(int x, int y, uint8_t *R, uint8_t *G, uint8_t *B, uint8_t *A);
	void		    getRGBA(uint32_t color, uint8_t *R, uint8_t *G, uint8_t *B, uint8_t *A);

	void		horzLineS(int x1, int y, int x2, uint32_t color);
	void		horzLine(int x1, int y, int x2, uint32_t color);

	bool        load(std::string filename, bool inversee = true);

	uint32_t 	mapRGBA(uint8_t R, uint8_t G, uint8_t B, uint8_t A);

	void		resize(int width, int height, bool antiAliased = true);

	uint32_t    save(std::string file);

	void		setAlpha(uint8_t alpha);
	void		setPixel(int x, int y, uint32_t color);
	void		setPixelS(int x, int y, uint32_t color);

	void		vertLineS(int x, int y1, int y2, uint32_t color);
	void		vertLine(int x, int y1, int y2, uint32_t color);

private:

	void 		_blit_RGB_RGB(ORect_i &srcRect, OSurface &dstSurface, ORect_i &dstRect);
    void 		_blit_RGB_RGBA(ORect_i &srcRect, OSurface &dstSurface, ORect_i &dstRect);
    void 		_blit_RGBA_RGB(ORect_i &srcRect, OSurface &dstSurface, ORect_i &dstRect);
    void 		_blit_RGBA_RGBA(ORect_i &srcRect, OSurface &dstSurface, ORect_i &dstRect);

	int 	    _calculatePitch(int testBpp = -1, int testWidth = -1);

	bool        _loadBMP(std::string filename, bool inversee);
	bool        _loadPNG(std::string filename, bool inversee);
	bool        _loadJPG(std::string filename, bool inversee);

	void		_setPixelRGB(int x, int y, uint32_t color);
	void		_setPixelRGBA(int x, int y, uint32_t color);
    void		_swap(void *byte1, void *byte2, int size);

private:

    int	        m_width;
    int	        m_height;
    int	        m_bpp;		//byte(s) per pixel (not bit)
    int	        m_pitch;	//bytes per row, including padding bytes

    uint8_t*    m_pixels;
    int	        m_format; 	//rgb rgba
};

#endif // OSurface_H_INCLUDED
