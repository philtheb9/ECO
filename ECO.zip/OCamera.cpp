#include "OCamera.h"


// -----------------------
// --- le constructeur ---
// -----------------------

OCamera::OCamera()
{
	m_speed = 0.0f;
	m_coefRot = 0.0f;
}

// ----------------------
// --- le destructeur ---
// ----------------------

OCamera::~OCamera()
{
    //
}

// --------------------
// --- les méthodes ---
// --------------------


void OCamera::anim()
{
    if (m_route.size() > 0)
    {
        m_pos.x = m_route[m_route_index].px;
        m_pos.y = m_route[m_route_index].py;
        m_pos.z = m_route[m_route_index].pz;

        m_rot.x = m_route[m_route_index].rx;
        m_rot.y = m_route[m_route_index].ry;
        m_rot.z = m_route[m_route_index].rz;

        _vectorFromAngle();

        m_route_index++;
        if (m_route_index+1 > m_route.size())
        {
            m_route_index = 0;
            m_route.clear();
        }
    }
}

/*
axe z verticale
rot.x = inclinaison rot.y = angleV rot.z = angleH
*/
void OCamera::create(float x, float y, float z, float angleH, float angleV)
{
    m_pos.set(x,y,z);
    m_rot.set(0.0f, angleV, angleH); // en degrés !

    m_speed = 0.25f;
    m_coefRot = 5.0f;

    m_route.clear();
    m_route_index = 0;

    _vectorFromAngle();
}

void OCamera::create(OVec3_f& pos, OVec3_f& rot)
{
    m_pos = pos;
    m_rot = rot;

    m_speed = 0.25f;
    m_coefRot = 3.5f;

    _vectorFromAngle();
}

float OCamera::getAngleH()
{
    return m_rot.z;
}

float OCamera::getAngleV()
{
    return m_rot.y;
}

float OCamera::getIncline()
{
    return m_rot.x;
}

OVec3_f& OCamera::getPos()
{
    return m_pos;
}

float OCamera::getPosX()
{
    return m_pos.x;
}

float OCamera::getPosY()
{
    return m_pos.y;
}

float OCamera::getPosZ()
{
    return m_pos.z;
}

OVec3_f& OCamera::getRegard()
{
    return m_regard;
}

OVec3_f& OCamera::getRot()
{
    return m_rot;
}

void OCamera::incAngleH(float value)
{
    m_rot.z += value;
    _vectorFromAngle();
}

void OCamera::incAngleV(float value)
{
    m_rot.y += value;
    _vectorFromAngle();
}

void OCamera::incIncline(float value)
{
    m_rot.x += value;
}

void OCamera::incPosX(float value)
{
    m_pos.x += value;
    m_cible = m_pos + m_regard;
}

void OCamera::incPosY(float value)
{
    m_pos.y += value;
    m_cible = m_pos + m_regard;
}

void OCamera::incPosZ(float value)
{
    m_pos.z += value;
    m_cible = m_pos + m_regard;
}



void OCamera::lookAt(OMat4& view)
{
    OVec3_f axeVertical(0.0f, 0.0f, 1.0f);

    view.rotate(m_rot.x, 0.0f, 0.0f, 1.0f);	//inclinaison de la tête
    view.lookAt(m_pos, m_cible, axeVertical);
}

/*
camera mode libre : on avance dans la direction du regard
compatibilité avec camFixe
*/
void OCamera::keyboard(OKeyboard& keyboard)
{
	//avance recule
	if (keyboard.getKeyDown(ECOK_n8))
	{
		move_front();
	}
	if (keyboard.getKeyDown(ECOK_n2))
	{
		move_back();
	}
	//déplacement gauche droite
	if (keyboard.getKeyDown(ECOK_n4))
	{
		move_side_left();
	}
	if (keyboard.getKeyDown(ECOK_n6))
	{
		move_side_right();
	}
	//tourne (la tete) gauche droite
	if (keyboard.getKeyDown(ECOK_n7))
	{
		move_left();
	}
	if (keyboard.getKeyDown(ECOK_n9))
	{
		move_right();
	}
	//monte descend (repère vertical z)
	if (keyboard.getKeyDown(ECOK_nAdd))
	{
		move_up();
	}
	if (keyboard.getKeyDown(ECOK_nSub))
	{
		move_down();
	}
	// inclinaison (de la tête) avant->bas arrière->haut
	if (keyboard.getKeyDown(ECOK_nDiv))
	{
		move_head_down();
	}
	if (keyboard.getKeyDown(ECOK_nMul))
	{
		move_head_up();
	}
	//inclinaison (de la tête) gauche droite
	if (keyboard.getKeyDown(ECOK_n1))
	{
		move_head_left();
	}
	if (keyboard.getKeyDown(ECOK_n3))
	{
		move_head_right();
	}
	//raz
	if (keyboard.getKeyDown(ECOK_n5))
	{
		move_raz();
	}
}

// free false (defaut) = camera mode marche : tourner la tête ne change rien à la direction
void OCamera::move_front(bool free)
{
    if (free)
    {
        m_pos += m_regard * m_speed;
        m_cible = m_pos + m_regard;
        return;
    }
    OVec3_f v3 = m_regard;
    v3.z = 0.0f;
    m_pos += v3 * m_speed;
    m_cible = m_pos + m_regard;
}

void OCamera::move_back(bool free)
{
    if (free)
    {
        m_pos -= m_regard * m_speed;
        m_cible = m_pos + m_regard;
        return;
    }
    OVec3_f v3 = m_regard;
    v3.z = 0.0f;
    m_pos -= v3 * m_speed;
    m_cible = m_pos + m_regard;
}

// rotation
void OCamera::move_left()
{
    m_rot.z += m_coefRot * m_speed;
    _vectorFromAngle();
}

void OCamera::move_right()
{
    m_rot.z -= m_coefRot * m_speed;
    _vectorFromAngle();
}

void OCamera::move_up(float acceleration)
{
    m_pos.z += m_speed * acceleration;
    m_cible = m_pos + m_regard;
}

void OCamera::move_down()
{
    m_pos.z -= m_speed;
    m_cible = m_pos + m_regard;
}

void OCamera::move_side_left()
{
    m_pos += m_cote * m_speed;
    m_cible = m_pos + m_regard;
}

void OCamera::move_side_right()
{
    m_pos -= m_cote * m_speed;
    m_cible = m_pos + m_regard;
}

void OCamera::move_head_down()
{
    m_rot.y -= m_coefRot * m_speed;
    _vectorFromAngle();
}

void OCamera::move_head_up()
{
    m_rot.y += m_coefRot * m_speed;
    _vectorFromAngle();
}

void OCamera::move_head_left()
{
    m_rot.x -= m_coefRot * m_speed;
}

void OCamera::move_head_right()
{
    m_rot.x += m_coefRot * m_speed;
}

void OCamera::move_raz()
{
    m_pos.set(0,0,0);
    m_rot.set(0,0,0);
    _vectorFromAngle();
}




void OCamera::setAngleH(float angleH)
{
    m_rot.z = angleH; // en degrés !
    _vectorFromAngle();
}

void OCamera::setAngleV(float angleV)
{
    m_rot.y = angleV; // en degrés !
    _vectorFromAngle();
}

void OCamera::setCoefRot(float value)
{
    m_coefRot = value;
}

void OCamera::setIncline(float value)
{
    m_rot.x = value;
}

void OCamera::setPos(OVec3_f& pos)
{
    m_pos = pos;
    m_cible = m_pos + m_regard;

    //ECO_error_set("%f", m_pos.z);
}

void OCamera::setPos(float x, float y, float z)
{
    m_pos.set(x,y,z);
    m_cible = m_pos + m_regard;

    //ECO_error_set("%f", m_pos.z);
}

/*
angles en degrés inclinaison/verticale/horizontale
*/
void OCamera::setRot(OVec3_f& rot)
{
    m_rot = rot;
    _vectorFromAngle();
}

void OCamera::setRot(float x, float y, float z)
{
    m_rot.set(x,y,z);
    _vectorFromAngle();
}

// value > 0.0
void OCamera::setSpeed(float value)
{
    if (value <= 0.0f) value = 0.25f;
    m_speed = value;
}

void OCamera::setSpeedRot(float value)
{
    if (value <= 0.0f) value = 2.5f;
    m_coefRot = value;
}

/*
suit le repositionnement de la cible (au sol)
point de référence cible : angle camera depuis cible !
*/
void OCamera::setTarget(OVec3_f pos, float angleH, float hauteur, float distance)
{
    float ang;

    if (angleH > 360.0f) angleH -= 360.0f;
    if (angleH < 0.0f) angleH += 360.0f;
//ECO_error_set("2 %f", angleH);

    ang = angleH * ECO_DEGTORAD;

    m_pos.x = pos.x + (cos(ang) * distance);
    m_pos.y = pos.y + (sin(ang) * distance);
    m_pos.z = hauteur;

    m_rot.x = 0.0f;

    // a prioris, on regarde depuis le dessus
    float hypothenuse = ECO_distanceVF(m_pos, pos);
    ang = std::asin(ECO_abs(m_pos.z - pos.z) / hypothenuse) ;
    ang *= ECO_RADTODEG;
    if ((m_pos.z - pos.z) < 0.0f) ang += 180.0f;
    m_rot.y = 360.0f - ang;

    m_rot.z = angleH+180.0f;

    _vectorFromAngle();

}

void OCamera::_vectorFromAngle()
{
    if (m_rot.z > 360.0f) m_rot.z -= 360.0f;
    if (m_rot.z < 0.0f) m_rot.z += 360.0f;

    // sécurité sinon saut de vue
    if (m_rot.y > 89.0f) m_rot.y = 89.0f;
    if (m_rot.y < -89.0f) m_rot.y = -89.0f;

    //float angleV = m_rot.y * static_cast<float>(ECO_DEGTORAD);
    //float angleH = m_rot.z * static_cast<float>(ECO_DEGTORAD);
    float angleV = m_rot.y * ECO_DEGTORAD;
    float angleH = m_rot.z * ECO_DEGTORAD;
    //regard
    m_regard.x = cos(angleV) * cos(angleH);
    m_regard.y = cos(angleV) * sin(angleH);
    m_regard.z = sin(angleV);

    m_cible = m_pos + m_regard;

    OVec3_f axeVertical(0.0f, 0.0f, 1.0f); // z
    //m_cote = axeVertical ^ m_regard;
    m_cote.cross(axeVertical, m_regard);
    m_cote.normalize();
}


// -------------
// --- route ---
// -------------

void OCamera::setRoute(OVec3_f poigne[4], float vitesse, OVec3_f& cible)
{
    //OVec3_f poigne[4];
    OVec3_f tmp1, tmp2;
    float longueur, deltatt, tt;
    float rx,ry,rz;

    m_route.clear();
    m_route_index = 0;

    longueur = (ECO_distance(poigne[0].x, poigne[0].y, poigne[1].x, poigne[1].y) +
                ECO_distance(poigne[1].x, poigne[1].y, poigne[2].x, poigne[2].y) +
                ECO_distance(poigne[2].x, poigne[2].y, poigne[3].x, poigne[3].y)) / 4;

    if (longueur < 1.0f)
    {
        //longueur = 1.0f;
        // pas de deplacement de moins d'un mètre
        return;
    }
    deltatt = 1.0f / longueur;

    tmp1 = poigne[0];
    tt = 0.0f;
    for (float i = vitesse; i < longueur; i+=vitesse)
    {
        tt = tt + deltatt*vitesse;
        tmp2 = _bezier(poigne, tt);

        if ( !(tmp1.x == tmp2.x && tmp1.y == tmp2.y))
        {
            tmp1 = tmp2;

            rx = 0.0f;
            ry = ECO_angle(tmp2.x, tmp2.z, cible.x, cible.z);
            rz = ECO_angle(tmp2.x, tmp2.y, cible.x, cible.y);

            m_route.push_back( Sbezier(tmp2.x, tmp2.y, tmp2.z, rx,ry,rz) );

            //ECO_error_set("cible %f %f %f", cible.x, cible.y, cible.z);
            //ECO_error_set("route %f %f", tmp2.x, tmp2.y);
            //ECO_error_set("regard %f %f %f", rx,ry,rz);
        }
    }
}

OVec3_f OCamera::_bezier(OVec3_f poigne[4], float interval)
{
    OVec3_f result;
    float t2;  //   t^2
    float t3;  //   t^3
    float r1, r2, r3, r4;
    // formule  (1-t)^3  = 1 - 3*t + 3*t^2 - t^3

    t2 = interval * interval;
    t3 = interval * t2;
    r1 = (1 - 3*interval + 3*t2 -   t3) * poigne[0].x;
    r2 = (    3*interval - 6*t2 + 3*t3) * poigne[1].x;
    r3 = (          3*t2 - 3*t3) * poigne[2].x;
    r4 = (                   t3) * poigne[3].x;

    result.x = r1 + r2 + r3 + r4;

    //t2 = interval * interval;
    //t3 = interval * t2;
    r1 = (1 - 3*interval + 3*t2 -   t3) * poigne[0].y;
    r2 = (    3*interval - 6*t2 + 3*t3) * poigne[1].y;
    r3 = (          3*t2 - 3*t3) * poigne[2].y;
    r4 = (                   t3) * poigne[3].y;

    result.y = r1 + r2 + r3 + r4;

    //t2 = interval * interval;
    //t3 = interval * t2;
    r1 = (1 - 3*interval + 3*t2 -   t3) * poigne[0].z;
    r2 = (    3*interval - 6*t2 + 3*t3) * poigne[1].z;
    r3 = (          3*t2 - 3*t3) * poigne[2].z;
    r4 = (                   t3) * poigne[3].z;

    result.z = r1 + r2 + r3 + r4;

    return result;
}

float OCamera::_rotation(float cap_actuel, float cap_demande)
{
    float sens = cap_actuel - cap_demande;
    float taux = 5.0f;

    if (sens < -180.0f)
    {
        cap_actuel -= taux;
    }
    else if (sens < 0.0f)
    {
        cap_actuel += taux;
    }
    else if (sens < 180.0f)
    {
        cap_actuel -= taux;
    }
    else
    {
        cap_actuel += taux;
    }

    if (ECO_abs(cap_actuel - cap_demande) <= taux)
    {
        cap_actuel = cap_demande;
    }
    if (cap_actuel < 0.0f) cap_actuel += 360.0f;
    if (cap_actuel >= 360.0f) cap_actuel -= 360.0f;

    return cap_actuel;
}

