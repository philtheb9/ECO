#ifndef ORECT_H_INCLUDED
#define ORECT_H_INCLUDED

/*
OBJET       classe d'un rectangle 2d (zone de bouton, label,etc...)

DATE        12/2017

AUTEUR      philippe Thebaud

COMMENTAIRE
*/

#include <GL/glew.h>
#include <GL/wglew.h>

//mode rect depuis coin left top ou centré
//prise en compte de la bordure ou non (pour l'intersection)
enum RectMode{ORECT_LEFTTOP_IN, ORECT_LEFTTOP_OUT, ORECT_CENTER_IN, ORECT_CENTER_OUT};

//les structures statiques
struct SRect_i { int x; int y; int w; int h; };
struct SRect_f { float x; float y; float w; float h; };
struct SRect_d { double x; double y; double w; double h; };


template <class T> class ORect
{
public:

    union{
		struct{T x, y, w, h;};
		struct{T left, top, bottom, right;};
		struct{T a0, a1, b0, b1;};
	};

    ORect()
    {
        x = 0;
        y = 0;
        w = 1; //>0 rend le ORect non NULL
        h = 1;
    };
    ORect(T,T,T,T);

    ORect operator () (T,T,T,T);
    ORect operator =  (const ORect& r);
    ORect operator =  (const SRect_i& r);
    ORect operator =  (const SRect_f& r);
    bool  operator == (const ORect& r);
	bool  operator != (const ORect& r);

    bool        isValid();

    bool        ptIn(T px, T py, RectMode mode = ORECT_LEFTTOP_IN) const;

    bool        rectIn(const ORect& r, RectMode mode = ORECT_LEFTTOP_IN) const;

    void        set(T vx, T vy, T vw, T vh);
    void        shift(int dx, int dy);

//acces direct
//private:
    //T x,y;
    //T w,h;

};

//les types Rect
typedef ORect<int>      ORect_i;
typedef ORect<float>    ORect_f;
typedef ORect<double>   ORect_d;

//le rect null (pour passage de null dans ECO_blit par exemple)
static ORect_i ORECT_NULL(0,0,0,0);

template <class T>
ORect<T>::ORect(T rx, T ry, T rw, T rh):x(rx),y(ry),w(rw),h(rh){}

template <class T>
ORect<T> ORect<T>::operator()(T rx, T ry, T rw, T rh)
{
    x = rx,
    y = ry;
    w = rw;
    h = rh;

    return *this;
}

template <class T>
ORect<T> ORect<T>::operator=(const ORect<T> &r)
{
    x = r.x,
    y = r.y;
    w = r.w;
    h = r.h;

    return *this;
}

template <class T>
ORect<T> ORect<T>::operator=(const SRect_i &r)
{
    x = r.x,
    y = r.y;
    w = r.w;
    h = r.h;

    return *this;
}

template <class T>
ORect<T> ORect<T>::operator=(const SRect_f &r)
{
    x = r.x,
    y = r.y;
    w = r.w;
    h = r.h;

    return *this;
}

template <class T>
bool ORect<T>::operator==(const ORect<T>& r)
{
    return
    (x == r.x) &&
    (y == r.y) &&
    (w == r.w) &&
    (h == r.h);
}

template <class T>
bool ORect<T>::operator!=(const ORect<T>& r)
{
    return
    (x != r.x) ||
    (y != r.y) ||
    (w != r.w) ||
    (h != r.h);
}

template <class T>
bool ORect<T>::isValid()
{
    return (w > 0) && (h > 0);
}

/*
retourne true si le point est à l'intérieur de la zone
*/
template <class T>
bool ORect<T>::ptIn(T px, T py, RectMode mode) const
{
    switch (mode)
    {
    //bordure comprise
    case ORECT_LEFTTOP_IN:
    	if (px < x) return false;
        if (py > y) return false;
        if (px > x+w) return false;
        if (py < y-h) return false;
        break;
    case ORECT_LEFTTOP_OUT:
    	if (px <= x) return false;
        if (py >= y) return false;
        if (px >= x+w) return false;
        if (py <= y-h) return false;
        break;
    case ORECT_CENTER_IN:
    	if (px < x-w) return false;
        if (py < y-h) return false;
        if (px > x+w) return false;
        if (py > y+h) return false;
        break;
    case ORECT_CENTER_OUT:
    	if (px <= x-w) return false;
        if (py <= y-h) return false;
        if (px >= x+w) return false;
        if (py >= y+h) return false;
        break;
    }

    return true;
}

/*
retourne true si le retangle passé est en intersection avec le rectangle source
*/
template <class T>
bool ORect<T>::rectIn(const ORect& r, RectMode mode) const
{
    switch (mode)
    {
    //bordure comprise
    case ORECT_LEFTTOP_IN:
        if (r.x > x + w) return false;
        if (r.y < y - h) return false;
        if (r.x + r.w < x) return false;
        if (r.y - r.h > y) return false;
        break;
    case ORECT_LEFTTOP_OUT:
        if (r.x >= x + w) return false;
        if (r.y <= y - h) return false;
        if (r.x + r.w <= x) return false;
        if (r.y - r.h >= y) return false;
        break;
    case ORECT_CENTER_IN:
        if (r.x - r.w > x + w) return false;
        if (r.y - r.h > y + h) return false;
        if (x - w > r.x + r.w) return false;
        if (y - h > r.y + r.h) return false;
        break;
    case ORECT_CENTER_OUT:
        if (r.x - r.w >= x + w) return false;
        if (r.y - r.h >= y + h) return false;
        if (x - w >= r.x + r.w) return false;
        if (y - h >= r.y + r.h) return false;
        break;
    }

    return true;
}

template <class T>
void ORect<T>::set(T vx, T vy, T vw, T vh)
{
    x = vx;
    y = vy;
    w = vw;
    h = vh;
}

template <class T>
void ORect<T>::shift(int dx, int dy)
{
    x += dx;
    y += dy;
}

#endif // ORECT_H_INCLUDED
