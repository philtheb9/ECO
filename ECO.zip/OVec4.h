#ifndef OVEC4_H_INCLUDED
#define OVEC4_H_INCLUDED
/*
OBJET       classe d'un vecteur 4d quaternion

DATE        12/2017

AUTEUR      philippe Thebaud

COMMENTAIRE
*/

#include <cmath>
#include <GL/glew.h>
#include <GL/wglew.h>


//les structures statiques
struct SVec4_i { int x; int y; int z; int w; };
struct SVec4_f { float x; float y; float z; float w; };


template <class T>
class OVec4
{
public:

	union{
		struct{T x, y, z, w;};
		struct{T r, g, b, a;};
	};

    OVec4() {x=0; y=0;z=0;w=0;};
    OVec4(const T vx, const T vy, const T vz, const T vw) { x=vx; y=vy; z=vz; w=vw; };
    OVec4(const T v[4]) { x=v[0]; y=v[1]; z=v[2]; w=v[3]; };


    void    set(const T vx, const T vy, const T vz, const T vw) { x=vx; y=vy; z=vz; w=vw; }


    OVec4& operator = (const OVec4& v4)
    {
        x = v4.x;
        y = v4.y;
        z = v4.z;
        w = v4.w;
        return(*this);
    }
    //pour transfert des donnees
    OVec4& operator = (const SVec4_f& v4)
    {
        x = v4.x;
        y = v4.y;
        z = v4.z;
        w = v4.w;
        return(*this);
    }
    OVec4& operator = (const SVec4_i& v4)
    {
        x = v4.x;
        y = v4.y;
        z = v4.z;
        w = v4.w;
        return(*this);
    }

    bool operator == (const OVec4& v4) const
    {
        return (x==v4.x && y==v4.y && z==v4.z && w==v4.w);
    }

    bool operator != (const OVec4& v4) const
    {
        return (x!=v4.x || y!=v4.y || z!=v4.z || w!=v4.w);
    }
    bool operator <= (const OVec4& v4) const
    {
        return (x <= v4.x && y <= v4.y && z <= v4.z && w <= v4.w);
    }
    bool operator >= (const OVec4& v4) const
    {
        return (x >= v4.x && y >= v4.y && z >= v4.z && w >= v4.w);
    }



    OVec4 operator + (const OVec4& v4)
    {
        OVec4 result(x+v4.x, y+v4.y, z+v4.z, w+v4.w);
        return result;
    }
    OVec4 operator - (const OVec4& v4)
    {
        OVec4 result(x-v4.x, y-v4.y, z-v4.z, w-v4.w);
        return result;
    }
    OVec4 operator * (const OVec4& v4)
    {
        OVec4 result(x*v4.x, y*v4.y, z*v4.z, w*v4.w);
        return result;
    }
    OVec4 operator / (const OVec4& v4)
    {
        OVec4 result(0,0,0,0);
        if (v4.x*v4.y*v4.z*v4.w == 0)
            return result;
        result.set(x/v4.x, y/v4.y, z/v4.z, w/v4.w);
        return result;
    }




    OVec4 operator + (const T value)
    {
        OVec4 result(x+value, y+value, z+value, w+value);
        return result;
    }
    OVec4 operator * (const T value)
    {
        OVec4 result(x*value, y*value, z*value, w*value);
        return result;
    }
    OVec4 operator / (const T value)
    {
        OVec4 result(0,0,0,0);
        if (value == 0) return result;
        result.set(x/value, y/value, z/value, w/value);
        return result;
    }
    OVec4 operator - () const
    {
        OVec4 result(-x, -y, -z, -w);
        return result;
    }
    //cross
    OVec4  operator ^ (const OVec4& v4) const
    {
        OVec4 result;
        result.x = (v4.w * w) - (v4.x * x) - (v4.y * y) - (v4.z * z);
        result.y = (v4.x * w) + (v4.w * x) + (v4.y * z) - (v4.z * y);
        result.z = (v4.y * w) + (v4.w * y) + (v4.z * x) - (v4.x * z);
        result.w = (v4.z * w) + (v4.w * z) + (v4.x * y) - (v4.y * x);
        return result;
    }


    void operator += (const OVec4 &v4)
    {
        x += v4.x;
        y += v4.y;
        z += v4.z;
        w += v4.w;
    }
    void operator -= (const OVec4 &v4)
    {
        x -= v4.x;
        y -= v4.y;
        z -= v4.z;
        w -= v4.w;
    }
    void operator *= (const OVec4 &v4)
    {
        x *= v4.x;
        y *= v4.y;
        z *= v4.z;
        w *= v4.w;
    }
    void operator /= (const OVec4 &v4)
    {
        if (v4.x*v4.y*v4.z*v4.w == 0) return;
        w /= v4.w;
        x /= v4.x;
        y /= v4.y;
        z /= v4.z;
    }



    void operator += (const T value)
    {
        x += value;
        y += value;
        z += value;
        w += value;
    }
    void operator -= (const T value)
    {
        x -= value;
        y -= value;
        z -= value;
        w -= value;
    }
    void operator *= (const T value)
    {
        x *= value;
        y *= value;
        z *= value;
        w *= value;
    }
    void operator /= (const T value)
    {
        if (value == 0) return;
        x /= value;
        y /= value;
        z /= value;
        w /= value;
    }



    T length() const
    {
        return ((T)sqrt(x*x+y*y+z*z+w*w));
    }
    T lengthSqr() const
    {
        return (x*x+y*y+z*z+w*w);
    };
    void normalize()
    {
        T lg = sqrtf(x*x + y*y + z*z + w*w);
        if (lg > 0)
        {
            const T a = 1.0 / lg; //1 seule division lente
            x *= a;
            y *= a;
            z *= a;
            w *= a;
        }
    }
};

typedef OVec4<float>    OVec4_f;
typedef OVec4<double>   OVec4_d;
typedef OVec4<int>      OVec4_i;

#endif

