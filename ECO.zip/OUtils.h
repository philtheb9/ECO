#ifndef OUTILS_H_INCLUDED
#define OUTILS_H_INCLUDED


#include <windows.h>
#include <GL/glew.h>
#include <GL/wglew.h>
#include <stdio.h>
#include <stdarg.h>	//argument de erreurs
#include <string.h>	//msg d'erreur et memcopy
#include <vector>
#include <string>
#include <stdint.h> //types int (uint32_t...

#include "OVec2.h"
#include "OVec3.h"
#include "OVec4.h"
#include "OMat4.h"
#include "ORect.h"

#include "OUtilsSys.h"
#include "OUtilsString.h"
#include "OUtilsFile.h"
#include "OUtilsMath.h"
#include "OUtilsDate.h"


// --------------------------
// définitions des structures
// --------------------------

//la structure de base pour récupérer/passer les paramètres d'une texture
/*
struct s_texParam
{
    uint32_t    id;
    int         w;
    int         h;

    s_texParam()
    {
        id = 0; w = 0; h = 0;
    }
};
*/
struct s_texParam
{
    uint32_t    id;
    int         w;
    int         h;

    s_texParam()
    {
        id = 0; w = 0; h = 0;
    }
};

// structure de base pour une date
struct SDate
{
    int     annee,mois,jour;
    int     heure,minute,seconde;
};



/*
lumiere
*/

// shader dir
enum { LIGHT_DIR, LIGHT_POINT, LIGHT_SPOT };
const int LIGHT_MAX = 5;  // 0 = lumière de base + 1->4 point ou spot


enum{ LUM_DETRUIT, LUM_ETEINT, LUM_ALLUME };


struct s_light
{
    int         type;
    int         state;

    OVec3_f     color;
    float       ambient;
    float       diffuse;
    OVec3_f     direction;

    OVec3_f     position;
    float       att_constant, att_linear, att_exp;
    float       cutoff;
    float       radius;

    s_light()
    {
        type = LIGHT_DIR;
        state = LUM_ETEINT;
        color.set(1.0f, 1.0f, 1.0f);
        ambient = 0.5f;
        diffuse = 0.5f;
        direction.set(0.0f, 1.0f, -1.0f);
        position.set(0.0f, 0.0f, 0.0f);
        // pour shader dir
        att_constant = 0.5f; // intensite : 0 fort > 1 faible
        att_linear = 0.1f;
        att_exp = 0.1f;
        // pour shader dir = ouverture cone du spot
        // defered = multiplcateur d'intensité (0.25f > 0.5 > 1.5f)
        cutoff = 30.0f;
    }
};

// ---------
// fonctions
// ---------

/*
fonctions permettant aux objets (notamment d'interface, OButton, OLabel, ...)
de récupérer la taillle de l'écran pour paramétrer leur matrice ortho
*/
void		ECO_setViewPort(int w, int h, int x = 0, int y = 0);
int         ECO_getViewPortW();
int         ECO_getViewPortH();

/*
position en 2d d'un point/vertex 3d

passer vp =
view.loadIdentity();
camera.lookAt(view);
vp = view * projection

int hw = ECO_getViewPortW() / 2;    // ou buffer
int hh = ECO_getViewPortH() / 2;
*/
OVec2_i		ECO_point3dTo2d(OMat4& vp, OVec3_f& pos, int hw, int hh);


// ---------------------------
// --- gestion des erreurs ---
// ---------------------------
//assure qu'un fichiers sortie existe (std::cerr ecrit dans la console, std::cout parfois n'écrit rien)

void 		ECO_error_set(const char *format, ...);
void 		ECO_error_write(bool write = true);

// --------------------------------
// --- gestion focus des objets ---
// --------------------------------
void*       ECO_getFocus();
void        ECO_setFocus(void *pointeurSurObjet);


// -----------------------
// --- fonctions macro ---
// -----------------------
//la taille des tableaux
#define ECO_sizeOf(a)   (sizeof(a)/sizeof(a[0]))
//
#define ECO_zeroMem(a)  memset(a, 0, sizeof(a))



// ---------------------------------
// --- definition des constantes ---
// ---------------------------------

//base math > redefini dans OUtilsMath
/*
#define ECO_DEGTORAD    0.0174532925199
#define ECO_RADTODEG    57.295827
#define ECO_PI	    	3.14159265358979323846
#define ECO_PI_2		1.57079632679489661923
#define ECO_PI_4		0.78539816339744830962
*/

#ifdef WIN32
	#define ECO_SEPARATOR	"\\"
	//#define SNPRINTF _snprintf_s
//#elif __APPLE__
#else
	#define ECO_SEPARATOR	"/"
	//#define SNPRINTF snprintf
#endif

//shader
#define INVALID_UNIFORM_LOCATION    0xFFFFFFFF
//ce code permet de spécifier un décalage offset en partant de l'adresse NULL (ou 0) pour l'instruction glVertexAttribPointer
#define BUFFER_OFFSET(offset) ((char*)NULL + (offset))
//plein ecran
//#define WM_TOGGLEFULLSCREEN (WM_USER+1)

// definition des constantes graphiques
//idem SDL
//#define MODE_LIL_ENDIAN	1234
//#define MODE_BIG_ENDIAN	4321

// mode byte perPixel (et non bit perPixel)
#define ECO_BPP3_24	3
#define ECO_BPP4_32	4


// definition des constantes mask et couleurs
//#if (MODE_BYTEORDER == MODE_LIL_ENDIAN)
	//
	#define ECO_amask	0xff000000
    #define ECO_rmask	0x00ff0000
    #define ECO_gmask	0x0000ff00
    #define ECO_bmask	0x000000ff

	#define ECO_ashift  24
    #define ECO_rshift  16
    #define ECO_gshift  8
    #define ECO_bshift  0

	#define ECO_byteFormat	GL_BGRA	//le format par defaut des surfaces créées

    //couleurs en 32 bits >ARGB window
    #define clClear32       0x00000000

    #define clBlack32       0xff000000

    #define clGrayLight32   0xffCCCCCC
    #define clGrayMed32     0xff999999
    #define clGray32        0xff666666
    #define clGrayDark32    0xff333333

    #define clCream32       0xffFFFFCC
    #define clWhite32       0xffFFFFFF

	#define clRed32         0xffFF0000
    #define clCarmin32      0xffE2001A
    #define clFuchsia32     0xffFF00FF

    #define clGreenLight32  0xff00FF00
    #define clGreen32       0xff007F00

	#define clBlue32        0xff0000FF
    #define clNavy32        0xff00007F
    #define clAqua32        0xff00FFFF
    #define clCyan32        0xffCC00CC
    #define clSkyBlue32     0xffCAF0A6

    #define clMaroon_l      0xffCBA674
    #define clMaroon_m      0xffAF8564
    #define clMaroon_h      0xff956939

    #define clYellow32      0xffFFFF00
    #define clYellow232     0xffEEBD67
    #define clOrange32      0xff4E8FF1

    #define clOcre32        0xff808000
    #define clOlive32       0xff7f7F00
    #define clPurple32      0xff7F007F
    #define clTeal32        0xff007F7f

    //50% transparentes
    #define clTrWhite32     0x7fFFFFFF
    #define clTrBlack32     0x7f000000
    #define clTrRed32       0x7fFF0000
    #define clTrGreen32     0x7f007F00
    #define clTrBlue32      0x7f0000FF

#endif // OCOMMON_H_INCLUDED
