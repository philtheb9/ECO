#include "OMat4.h"


// -----------------------
// --- le constructeur ---
// -----------------------

OMat4::OMat4()
{
    //m_ptPile = 0;
    for(int i = 0; i < 16; i++)
        m_value[i] = 0.0f;
}

OMat4::OMat4(const float *v)
{
    //m_ptPile = 0;
    for(int i = 0; i < 16; i++)
        m_value[i] = v[i];
}

OMat4::OMat4(const OMat4& m4)
{
    //m_ptPile = 0;
    for(int i = 0; i < 16; i++)
        m_value[i] = m4.m_value[i];
}

// ----------------------
// --- le destructeur ---
// ----------------------

OMat4::~OMat4()
{
    //_depiler();
}

// ----------------------
// --- les op�rateurs ---
// ----------------------

OMat4 OMat4::operator * (const OMat4& m4) const
{
    OMat4 result,tmp;

    tmp = m4;
    for(int k = 0; k < 4; k++)
    {
        for(int j = 0; j < 4; j++)
        {
            for(int i = 0; i < 4; i++)
                result.m_value[4 * j + k] += m_value[4 * j + i] * tmp.m_value[4 * i + k];
        }
    }

    return result;
}

OMat4 OMat4::operator * (const float v) const
{
	OMat4 result;

	result.m_value[0] = m_value[0]*v;
    result.m_value[1] = m_value[1]*v;
    result.m_value[2] = m_value[2]*v;
    result.m_value[3] = m_value[3]*v;
    result.m_value[4] = m_value[4]*v;
    result.m_value[5] = m_value[5]*v;
    result.m_value[6] = m_value[6]*v;
    result.m_value[7] = m_value[7]*v;
    result.m_value[8] = m_value[8]*v;
    result.m_value[9] = m_value[9]*v;
    result.m_value[10] = m_value[10]*v;
    result.m_value[11] = m_value[11]*v;
    result.m_value[12] = m_value[12]*v;
    result.m_value[13] = m_value[13]*v;
    result.m_value[14] = m_value[14]*v;
    result.m_value[15] = m_value[15]*v;

    return result;
}

OMat4& OMat4::operator = (const OMat4& m4)
{
    for(int i = 0; i < 16; i++)
        m_value[i] = m4.m_value[i];

    return *this;
}

OMat4 OMat4::operator / (const float value) const
{
	if (value == 0.0f || value == 1.0f)
		return (*this);

	float temp = 1 / value;

	return (*this)*temp;
}

OMat4 OMat4::operator + (const OMat4& m4) const
{
	OMat4 result;

	result.m_value[0] = m4.m_value[0] + m_value[0];
    result.m_value[1] = m4.m_value[1] + m_value[1];
    result.m_value[2] = m4.m_value[2] + m_value[2];
    result.m_value[3] = m4.m_value[3] + m_value[3];
    result.m_value[4] = m4.m_value[4] + m_value[4];
    result.m_value[5] = m4.m_value[5] + m_value[5];
    result.m_value[6] = m4.m_value[6] + m_value[6];
    result.m_value[7] = m4.m_value[7] + m_value[7];
    result.m_value[8] = m4.m_value[8] + m_value[8];
    result.m_value[9] = m4.m_value[9] + m_value[9];
    result.m_value[10] = m4.m_value[10] + m_value[10];
    result.m_value[11] = m4.m_value[11] + m_value[11];
    result.m_value[12] = m4.m_value[12] + m_value[12];
    result.m_value[13] = m4.m_value[13] + m_value[13];
    result.m_value[14] = m4.m_value[14] + m_value[14];
    result.m_value[15] = m4.m_value[15] + m_value[15];

    return result;
}

OMat4 OMat4::operator - (const OMat4& m4) const
{
	OMat4 result;

	result.m_value[0] = m_value[0] - m4.m_value[0];
    result.m_value[1] = m_value[1] - m4.m_value[1];
    result.m_value[2] = m_value[2] - m4.m_value[2];
    result.m_value[3] = m_value[3] - m4.m_value[3];
    result.m_value[4] = m_value[4] - m4.m_value[4];
    result.m_value[5] = m_value[5] - m4.m_value[5];
    result.m_value[6] = m_value[6] - m4.m_value[6];
    result.m_value[7] = m_value[7] - m4.m_value[7];
    result.m_value[8] = m_value[8] - m4.m_value[8];
    result.m_value[9] = m_value[9] - m4.m_value[9];
    result.m_value[10] = m_value[10] - m4.m_value[10];
    result.m_value[11] = m_value[11] - m4.m_value[11];
    result.m_value[12] = m_value[12] - m4.m_value[12];
    result.m_value[13] = m_value[13] - m4.m_value[13];
    result.m_value[14] = m_value[14] - m4.m_value[14];
    result.m_value[15] = m_value[15] - m4.m_value[15];

    return result;
}

OVec3_f OMat4::operator * (const OVec3_f& v3) const
{
	return OVec3_f(m_value[0]*v3.x
                + m_value[4]*v3.y
                + m_value[8]*v3.z,

                  m_value[1]*v3.x
                + m_value[5]*v3.y
                + m_value[9]*v3.z,

                  m_value[2]*v3.x
                + m_value[6]*v3.y
                + m_value[10]*v3.z
                );
}

OVec4_f OMat4::operator * (const OVec4_f& v4) const
{
	//optimisation
	if (m_value[3] == 0.0f && m_value[7] == 0.0f && m_value[11] == 0.0f && m_value[15] == 1.0f)
	{
		return OVec4_f(m_value[0]*v4.x
					+	m_value[4]*v4.y
					+	m_value[8]*v4.z
					+	m_value[12]*v4.w,

						m_value[1]*v4.x
					+	m_value[5]*v4.y
					+	m_value[9]*v4.z
					+	m_value[13]*v4.w,

						m_value[2]*v4.x
					+	m_value[6]*v4.y
					+	m_value[10]*v4.z
					+	m_value[14]*v4.w,

						v4.w);
	}

	return OVec4_f(	m_value[0]*v4.x
					+	m_value[4]*v4.y
					+	m_value[8]*v4.z
					+	m_value[12]*v4.w,

						m_value[1]*v4.x
					+	m_value[5]*v4.y
					+	m_value[9]*v4.z
					+	m_value[13]*v4.w,

						m_value[2]*v4.x
					+	m_value[6]*v4.y
					+	m_value[10]*v4.z
					+	m_value[14]*v4.w,

						m_value[3]*v4.x
					+	m_value[7]*v4.y
					+	m_value[11]*v4.z
					+	m_value[15]*v4.w);
}


void OMat4::operator += (const OMat4& m4)
{
	(*this)=(*this)+m4;
}

void OMat4::operator -= (const OMat4& m4)
{
	(*this)=(*this)-m4;
}

void OMat4::operator *= (const OMat4& m4)
{
	(*this)=(*this)*m4;
}

// --------------------
// --- les m�thodes ---
// --------------------

void OMat4::clear()
{
    for(int i = 0; i < 16; i++)
        m_value[i] = 0.0f;
    //ZERO_MEM(a) memset(a, 0, sizeof(a))
}
/*
void OMat4::_depiler()
{
    //tant qu'il y a des sauvegardes, on les d�truit
    while(pop() != false);
}
*/
/*
retour des valeurs pour les appels shader->matrice
*/
float const* OMat4::getFv() const
{
    return (float* const) m_value;
}

/*
retourne une copie invers�e de la m4
transpose parfois necessaire avant
*/
OMat4 OMat4::getInverse() const
{
	OMat4 result;

	float tmp[12];	//stockage tmp
	float det;		//determinant
	//
	tmp[0] = m_value[10] * m_value[15];
	tmp[1] = m_value[11] * m_value[14];
	tmp[2] = m_value[9] * m_value[15];
	tmp[3] = m_value[11] * m_value[13];
	tmp[4] = m_value[9] * m_value[14];
	tmp[5] = m_value[10] * m_value[13];
	tmp[6] = m_value[8] * m_value[15];
	tmp[7] = m_value[11] * m_value[12];
	tmp[8] = m_value[8] * m_value[14];
	tmp[9] = m_value[10] * m_value[12];
	tmp[10] = m_value[8] * m_value[13];
	tmp[11] = m_value[9] * m_value[12];

	//
	result.setValue(0,	tmp[0]*m_value[5] + tmp[3]*m_value[6] + tmp[4]*m_value[7]
					-	tmp[1]*m_value[5] - tmp[2]*m_value[6] - tmp[5]*m_value[7]);

	result.setValue(1,	tmp[1]*m_value[4] + tmp[6]*m_value[6] + tmp[9]*m_value[7]
					-	tmp[0]*m_value[4] - tmp[7]*m_value[6] - tmp[8]*m_value[7]);

	result.setValue(2,	tmp[2]*m_value[4] + tmp[7]*m_value[5] + tmp[10]*m_value[7]
					-	tmp[3]*m_value[4] - tmp[6]*m_value[5] - tmp[11]*m_value[7]);

	result.setValue(3,	tmp[5]*m_value[4] + tmp[8]*m_value[5] + tmp[11]*m_value[6]
					-	tmp[4]*m_value[4] - tmp[9]*m_value[5] - tmp[10]*m_value[6]);

	result.setValue(4,	tmp[1]*m_value[1] + tmp[2]*m_value[2] + tmp[5]*m_value[3]
					-	tmp[0]*m_value[1] - tmp[3]*m_value[2] - tmp[4]*m_value[3]);

	result.setValue(5,	tmp[0]*m_value[0] + tmp[7]*m_value[2] + tmp[8]*m_value[3]
					-	tmp[1]*m_value[0] - tmp[6]*m_value[2] - tmp[9]*m_value[3]);

	result.setValue(6,	tmp[3]*m_value[0] + tmp[6]*m_value[1] + tmp[11]*m_value[3]
					-	tmp[2]*m_value[0] - tmp[7]*m_value[1] - tmp[10]*m_value[3]);

	result.setValue(7,	tmp[4]*m_value[0] + tmp[9]*m_value[1] + tmp[10]*m_value[2]
					-	tmp[5]*m_value[0] - tmp[8]*m_value[1] - tmp[11]*m_value[2]);

	//
	tmp[0] = m_value[2]*m_value[7];
	tmp[1] = m_value[3]*m_value[6];
	tmp[2] = m_value[1]*m_value[7];
	tmp[3] = m_value[3]*m_value[5];
	tmp[4] = m_value[1]*m_value[6];
	tmp[5] = m_value[2]*m_value[5];
	tmp[6] = m_value[0]*m_value[7];
	tmp[7] = m_value[3]*m_value[4];
	tmp[8] = m_value[0]*m_value[6];
	tmp[9] = m_value[2]*m_value[4];
	tmp[10] = m_value[0]*m_value[5];
	tmp[11] = m_value[1]*m_value[4];

	//
	result.setValue(8,	tmp[0]*m_value[13] + tmp[3]*m_value[14] + tmp[4]*m_value[15]
					-	tmp[1]*m_value[13] - tmp[2]*m_value[14] - tmp[5]*m_value[15]);

	result.setValue(9,	tmp[1]*m_value[12] + tmp[6]*m_value[14] + tmp[9]*m_value[15]
					-	tmp[0]*m_value[12] - tmp[7]*m_value[14] - tmp[8]*m_value[15]);

	result.setValue(10,	tmp[2]*m_value[12] + tmp[7]*m_value[13] + tmp[10]*m_value[15]
					-	tmp[3]*m_value[12] - tmp[6]*m_value[13] - tmp[11]*m_value[15]);

	result.setValue(11,	tmp[5]*m_value[12] + tmp[8]*m_value[13] + tmp[11]*m_value[14]
					-	tmp[4]*m_value[12] - tmp[9]*m_value[13] - tmp[10]*m_value[14]);

	result.setValue(12,	tmp[2]*m_value[10] + tmp[5]*m_value[11] + tmp[1]*m_value[9]
					-	tmp[4]*m_value[11] - tmp[0]*m_value[9] - tmp[3]*m_value[10]);

	result.setValue(13,	tmp[8]*m_value[11] + tmp[0]*m_value[8] + tmp[7]*m_value[10]
					-	tmp[6]*m_value[10] - tmp[9]*m_value[11] - tmp[1]*m_value[8]);

	result.setValue(14,	tmp[6]*m_value[9] + tmp[11]*m_value[11] + tmp[3]*m_value[8]
					-	tmp[10]*m_value[11] - tmp[2]*m_value[8] - tmp[7]*m_value[9]);

	result.setValue(15,	tmp[10]*m_value[10] + tmp[4]*m_value[8] + tmp[9]*m_value[9]
					-	tmp[8]*m_value[9] - tmp[11]*m_value[10] - tmp[5]*m_value[8]);

	det	=	 m_value[0]*result.getValue(0)
			+m_value[1]*result.getValue(1)
			+m_value[2]*result.getValue(2)
			+m_value[3]*result.getValue(3);

	if (det == 0.0f)
	{
		OMat4 id;
		return id;
	}

	result = result / det;

	return result;
}



void OMat4::initRotateTransform(float RotateX, float RotateY, float RotateZ)
{
	OMat4 rx, ry, rz;
	/*
	const float x = ToRadian(RotateX);
	const float y = ToRadian(RotateY);
	const float z = ToRadian(RotateZ);

	rx.m[0][0] = 1.0f; rx.m[0][1] = 0.0f; rx.m[0][2] = 0.0f; rx.m[0][3] = 0.0f;
	rx.m[1][0] = 0.0f; rx.m[1][1] = cosf(x); rx.m[1][2] = -sinf(x); rx.m[1][3] = 0.0f;
	rx.m[2][0] = 0.0f; rx.m[2][1] = sinf(x); rx.m[2][2] = cosf(x); rx.m[2][3] = 0.0f;
	rx.m[3][0] = 0.0f; rx.m[3][1] = 0.0f; rx.m[3][2] = 0.0f; rx.m[3][3] = 1.0f;

	ry.m[0][0] = cosf(y); ry.m[0][1] = 0.0f; ry.m[0][2] = -sinf(y); ry.m[0][3] = 0.0f;
	ry.m[1][0] = 0.0f; ry.m[1][1] = 1.0f; ry.m[1][2] = 0.0f; ry.m[1][3] = 0.0f;
	ry.m[2][0] = sinf(y); ry.m[2][1] = 0.0f; ry.m[2][2] = cosf(y); ry.m[2][3] = 0.0f;
	ry.m[3][0] = 0.0f; ry.m[3][1] = 0.0f; ry.m[3][2] = 0.0f; ry.m[3][3] = 1.0f;

	rz.m[0][0] = cosf(z); rz.m[0][1] = -sinf(z); rz.m[0][2] = 0.0f; rz.m[0][3] = 0.0f;
	rz.m[1][0] = sinf(z); rz.m[1][1] = cosf(z); rz.m[1][2] = 0.0f; rz.m[1][3] = 0.0f;
	rz.m[2][0] = 0.0f; rz.m[2][1] = 0.0f; rz.m[2][2] = 1.0f; rz.m[2][3] = 0.0f;
	rz.m[3][0] = 0.0f; rz.m[3][1] = 0.0f; rz.m[3][2] = 0.0f; rz.m[3][3] = 1.0f;

	*this = rz * ry * rx;
	*/
	const float DEGTORAD = 0.0174532925199f;
	const float x = RotateX * DEGTORAD;
	const float y = RotateY * DEGTORAD;
	const float z = RotateZ * DEGTORAD;

	rx.setValue(0, 1.0f); rx.setValue(1, 1.0f); rx.setValue(2, 0.0f); rx.setValue(3, 0.0f);
	rx.setValue(4, 0.0f); rx.setValue(5, cosf(x)); rx.setValue(6, -sinf(x)); rx.setValue(7, 0.0f);
	rx.setValue(8, 0.0f); rx.setValue(9, sinf(x)); rx.setValue(10, cosf(x)); rx.setValue(11, 0.0f);
	rx.setValue(12, 0.0f); rx.setValue(13, 0.0f); rx.setValue(14, 0.0f); rx.setValue(15, 1.0f);

	ry.setValue(0, cosf(y)); ry.setValue(1, 0.0f); ry.setValue(2, -sinf(y)); ry.setValue(3, 0.0f);
	ry.setValue(4, 0.0f); ry.setValue(5, 1.0f); ry.setValue(6, 0.0f); ry.setValue(7, 0.0f);
	ry.setValue(8, sinf(y)); ry.setValue(9, 0.0f); ry.setValue(10, cosf(y)); ry.setValue(11, 0.0f);
	ry.setValue(12, 0.0f); ry.setValue(13, 0.0f); ry.setValue(14, 0.0f); ry.setValue(15, 1.0f);

	rz.setValue(0, cosf(z)); rz.setValue(1, -sinf(z)); rz.setValue(2, 0.0f); rz.setValue(3, 0.0f);
	rz.setValue(4, sinf(z)); rz.setValue(5, cosf(z)); rz.setValue(6, 0.0f); rz.setValue(7, 0.0f);
	rz.setValue(8, 0.0f); rz.setValue(9, 0.0f); rz.setValue(10, 1.0f); rz.setValue(11, 0.0f);
	rz.setValue(12, 0.0f); rz.setValue(13, 0.0f); rz.setValue(14, 0.0f); rz.setValue(15, 1.0f);

	*this = rz * ry * rx;
}


void OMat4::initScaleTransform(float x, float y, float z)
{
	//m[0][0] = ScaleX; m[0][1] = 0.0f;   m[0][2] = 0.0f;   m[0][3] = 0.0f;
	//m[1][0] = 0.0f;   m[1][1] = ScaleY; m[1][2] = 0.0f;   m[1][3] = 0.0f;
	//m[2][0] = 0.0f;   m[2][1] = 0.0f;   m[2][2] = ScaleZ; m[2][3] = 0.0f;
	//m[3][0] = 0.0f;   m[3][1] = 0.0f;   m[3][2] = 0.0f;   m[3][3] = 1.0f;

	m_value[0] = x;
	m_value[1] = 0.0f;
	m_value[2] = 0.0f;
	m_value[3] = 0.0f;

	m_value[4] = 0.0f;
	m_value[5] = y;
	m_value[6] = 0.0f;
	m_value[7] = 0.0f;

	m_value[8] = 0.0f;
	m_value[9] = 0.0f;
	m_value[10] = z;
	m_value[11] = 0.0f;

	m_value[12] = 0.0f;
	m_value[13] = 0.0f;
	m_value[14] = 0.0f;
	m_value[15] = 1.0f;
}

void OMat4::initTranslationTransform(float x, float y, float z)
{
	//m[0][0] = 1.0f; m[0][1] = 0.0f; m[0][2] = 0.0f; m[0][3] = x;
	//m[1][0] = 0.0f; m[1][1] = 1.0f; m[1][2] = 0.0f; m[1][3] = y;
	//m[2][0] = 0.0f; m[2][1] = 0.0f; m[2][2] = 1.0f; m[2][3] = z;
	//m[3][0] = 0.0f; m[3][1] = 0.0f; m[3][2] = 0.0f; m[3][3] = 1.0f;

	m_value[0] = 1.0f;
	m_value[1] = 0.0f;
	m_value[2] = 0.0f;
	m_value[3] = x;

	m_value[4] = 0.0f;
	m_value[5] = 1.0f;
	m_value[6] = 0.0f;
	m_value[7] = y;

	m_value[8] = 0.0f;
	m_value[9] = 0.0f;
	m_value[10] = 1.0f;
	m_value[11] = z;

	m_value[12] = 0.0f;
	m_value[13] = 0.0f;
	m_value[14] = 0.0f;
	m_value[15] = 1.0f;
}

void OMat4::inverse()
{
	OMat4 result;

	float tmp[12];	//stockage tmp
	float det;		//determinant
	//
	tmp[0] = m_value[10] * m_value[15];
	tmp[1] = m_value[11] * m_value[14];
	tmp[2] = m_value[9] * m_value[15];
	tmp[3] = m_value[11] * m_value[13];
	tmp[4] = m_value[9] * m_value[14];
	tmp[5] = m_value[10] * m_value[13];
	tmp[6] = m_value[8] * m_value[15];
	tmp[7] = m_value[11] * m_value[12];
	tmp[8] = m_value[8] * m_value[14];
	tmp[9] = m_value[10] * m_value[12];
	tmp[10] = m_value[8] * m_value[13];
	tmp[11] = m_value[9] * m_value[12];

	//
	result.setValue(0,	tmp[0]*m_value[5] + tmp[3]*m_value[6] + tmp[4]*m_value[7]
					-	tmp[1]*m_value[5] - tmp[2]*m_value[6] - tmp[5]*m_value[7]);

	result.setValue(1,	tmp[1]*m_value[4] + tmp[6]*m_value[6] + tmp[9]*m_value[7]
					-	tmp[0]*m_value[4] - tmp[7]*m_value[6] - tmp[8]*m_value[7]);

	result.setValue(2,	tmp[2]*m_value[4] + tmp[7]*m_value[5] + tmp[10]*m_value[7]
					-	tmp[3]*m_value[4] - tmp[6]*m_value[5] - tmp[11]*m_value[7]);

	result.setValue(3,	tmp[5]*m_value[4] + tmp[8]*m_value[5] + tmp[11]*m_value[6]
					-	tmp[4]*m_value[4] - tmp[9]*m_value[5] - tmp[10]*m_value[6]);

	result.setValue(4,	tmp[1]*m_value[1] + tmp[2]*m_value[2] + tmp[5]*m_value[3]
					-	tmp[0]*m_value[1] - tmp[3]*m_value[2] - tmp[4]*m_value[3]);

	result.setValue(5,	tmp[0]*m_value[0] + tmp[7]*m_value[2] + tmp[8]*m_value[3]
					-	tmp[1]*m_value[0] - tmp[6]*m_value[2] - tmp[9]*m_value[3]);

	result.setValue(6,	tmp[3]*m_value[0] + tmp[6]*m_value[1] + tmp[11]*m_value[3]
					-	tmp[2]*m_value[0] - tmp[7]*m_value[1] - tmp[10]*m_value[3]);

	result.setValue(7,	tmp[4]*m_value[0] + tmp[9]*m_value[1] + tmp[10]*m_value[2]
					-	tmp[5]*m_value[0] - tmp[8]*m_value[1] - tmp[11]*m_value[2]);

	//
	tmp[0] = m_value[2]*m_value[7];
	tmp[1] = m_value[3]*m_value[6];
	tmp[2] = m_value[1]*m_value[7];
	tmp[3] = m_value[3]*m_value[5];
	tmp[4] = m_value[1]*m_value[6];
	tmp[5] = m_value[2]*m_value[5];
	tmp[6] = m_value[0]*m_value[7];
	tmp[7] = m_value[3]*m_value[4];
	tmp[8] = m_value[0]*m_value[6];
	tmp[9] = m_value[2]*m_value[4];
	tmp[10] = m_value[0]*m_value[5];
	tmp[11] = m_value[1]*m_value[4];

	//
	result.setValue(8,	tmp[0]*m_value[13] + tmp[3]*m_value[14] + tmp[4]*m_value[15]
					-	tmp[1]*m_value[13] - tmp[2]*m_value[14] - tmp[5]*m_value[15]);

	result.setValue(9,	tmp[1]*m_value[12] + tmp[6]*m_value[14] + tmp[9]*m_value[15]
					-	tmp[0]*m_value[12] - tmp[7]*m_value[14] - tmp[8]*m_value[15]);

	result.setValue(10,	tmp[2]*m_value[12] + tmp[7]*m_value[13] + tmp[10]*m_value[15]
					-	tmp[3]*m_value[12] - tmp[6]*m_value[13] - tmp[11]*m_value[15]);

	result.setValue(11,	tmp[5]*m_value[12] + tmp[8]*m_value[13] + tmp[11]*m_value[14]
					-	tmp[4]*m_value[12] - tmp[9]*m_value[13] - tmp[10]*m_value[14]);

	result.setValue(12,	tmp[2]*m_value[10] + tmp[5]*m_value[11] + tmp[1]*m_value[9]
					-	tmp[4]*m_value[11] - tmp[0]*m_value[9] - tmp[3]*m_value[10]);

	result.setValue(13,	tmp[8]*m_value[11] + tmp[0]*m_value[8] + tmp[7]*m_value[10]
					-	tmp[6]*m_value[10] - tmp[9]*m_value[11] - tmp[1]*m_value[8]);

	result.setValue(14,	tmp[6]*m_value[9] + tmp[11]*m_value[11] + tmp[3]*m_value[8]
					-	tmp[10]*m_value[11] - tmp[2]*m_value[8] - tmp[7]*m_value[9]);

	result.setValue(15,	tmp[10]*m_value[10] + tmp[4]*m_value[8] + tmp[9]*m_value[9]
					-	tmp[8]*m_value[9] - tmp[11]*m_value[10] - tmp[5]*m_value[8]);

	det	=	 m_value[0]*result.getValue(0)
			+m_value[1]*result.getValue(1)
			+m_value[2]*result.getValue(2)
			+m_value[3]*result.getValue(3);

	if (det == 0.0f)
		return;

	result = result / det;
    *this = *this * result;
}

/*
recup�re une valeur (pour faire une copie des valeurs par exemple)
*/
float OMat4::getValue(int idx) const
{
    return m_value[idx];
}

void OMat4::loadIdentity()
{
    m_value[0] = 1.0f;
    m_value[1] = 0.0f;
    m_value[2] = 0.0f;
    m_value[3] = 0.0f;

    m_value[4] = 0.0f;
    m_value[5] = 1.0f;
    m_value[6] = 0.0f;
    m_value[7] = 0.0f;

    m_value[8] = 0.0f;
    m_value[9] = 0.0f;
    m_value[10] = 1.0f;
    m_value[11] = 0.0f;

    m_value[12] = 0.0f;
    m_value[13] = 0.0f;
    m_value[14] = 0.0f;
    m_value[15] = 1.0f;
}

void OMat4::lookAt(OVec3_f& eye, OVec3_f& center, OVec3_f& up)
{
    OVec3_f regard = center - eye;
    OVec3_f normal;
    OVec3_f newAxe;

    OMat4 tmp;

    normal = regard ^ up;
    newAxe = normal ^ regard;

    normal.normalize();
    newAxe.normalize();
    regard.normalize();

    tmp.m_value[0] = normal.x;
    tmp.m_value[1] = normal.y;
    tmp.m_value[2] = normal.z;

    tmp.m_value[4] = newAxe.x;
    tmp.m_value[5] = newAxe.y;
    tmp.m_value[6] = newAxe.z;

    tmp.m_value[8] = -regard.x;
    tmp.m_value[9] = -regard.y;
    tmp.m_value[10] = -regard.z;

    tmp.m_value[15] = 1.0;

    *this = *this * tmp;
    translate(eye * -1);
}

void OMat4::lookAt(float eyeX, float eyeY, float eyeZ, float centerX, float centerY, float centerZ, float upX, float upY, float upZ)
{
    OVec3_f eye(eyeX, eyeY, eyeZ);
    OVec3_f center(centerX, centerY, centerZ);
    OVec3_f up(upX, upY, upZ);

    lookAt(eye, center, up);
}

void OMat4::ortho(float left, float bottom, float right, float top, float _near, float _far)
{
    if (left == right || top == bottom || _far == _near)
        return;

    loadIdentity();

	m_value[0] = 2.0f / (right-left);
	m_value[5] = 2.0f / (top-bottom);
	m_value[10] = -2.0f / (_far-_near);

	m_value[3] = -(right+left) / (right-left);
	m_value[7] = -(top+bottom) / (top-bottom);
	m_value[11] = -(_far+_near) / (_far-_near);
}

void OMat4::ortho(float w, float h)
{
    loadIdentity();

	m_value[0] = 2.0f / w;
	m_value[5] = 2.0f / h;
    m_value[10] = -1.0f;

	m_value[3] = -1.0f; //-(w+left) / (w-left);
	m_value[7] = -1.0f; //-(top+bottom) / (top-bottom);
	m_value[11] = -1.0f;
}

void OMat4::ortho(int w, int h)
{
	loadIdentity();

	m_value[0] = 2.0f / static_cast<float>(w);
	m_value[5] = 2.0f / static_cast<float>(h);
	m_value[10] = -1.0f;

	m_value[3] = -1.0f; //-(w+left) / (w-left);
	m_value[7] = -1.0f; //-(top+bottom) / (top-bottom);
	m_value[11] = -1.0f;
}

void OMat4::perspective(float fovy, float aspect, float _near, float _far)
{
	float left, right, top, bottom;

	fovy *= 0.01745329f;

	top = _near * tanf(fovy / 2.0f);
	bottom = -top;

	left = aspect*bottom;
	right = aspect*top;

	perspective(left, right, bottom, top, _near, _far);
}

void OMat4::perspective(float left, float right, float bottom,	float top, float _near, float _far)
{
	float infini = 0.999f; //_far infini

	if (left == right || top == bottom || _near == _far)
		return;

    loadIdentity();

	m_value[0] = (2.0f*_near) / (right-left);
	m_value[5] = (2.0f*_near) / (top-bottom);
	m_value[2] = (right+left) / (right-left);
	m_value[6] = (top+bottom) / (top-bottom);

	if (_far != -1.0f)
	{
		m_value[10] = -(_far+_near) / (_far-_near);
	}
	else		//if f==-1, use an infinite _far plane
	{
		m_value[10] = -infini;
	}

	m_value[14] = -1.0f;

	if (_far != -1.0f)
	{
		m_value[11] = -(2.0f*_far*_near) / (_far-_near);
	}
	else		//if f==-1, use an infinite _far plane
	{
		m_value[11] = -2.0f*_near*infini;
	}
}
/*
GLboolean OMat4::pop()
{
    OMat4 *tmp = m_ptPile;

    if(tmp != 0)
    {
        //copie des valeurs depuis la sauvegarde
        *this = *tmp;
        //red�finition du sommet de la pile
        m_ptPile = tmp->m_ptPile;
        //on lib�re la sauvegarde � supprimer
        tmp->m_ptPile = 0;
        delete tmp;

        return true;
    }

    return false;
}

GLboolean OMat4::push()
{
    //nouvelle case dans la pile
    OMat4 *newCase = new OMat4;

    if(newCase != 0)
    {
        //copie des valeurs dans la nouvelle case
        *newCase = *this;
        //on pointe sur la sauvegarde pr�c�dente
        newCase->m_ptPile = m_ptPile;
        //red�finition du sommet de la pile
        m_ptPile = newCase;

        return true;
    }

    return false;
}
*/
void OMat4::rotate(float angle, OVec3_f& axe)
{
    OMat4 tmp;

    if (angle == 0.0f) return;

    angle = angle * 0.01745329f;
    float cosAngle1 = (1.0f-cos(angle));
    float cosAngle = cos(angle);
    float sinAngle = sin(angle);

    axe.normalize();
    tmp.m_value[0] =  axe.x * axe.x * cosAngle1 + cosAngle;
    tmp.m_value[1] =  axe.x * axe.y * cosAngle1 - axe.z * sinAngle;
    tmp.m_value[2] =  axe.x * axe.z * cosAngle1 + axe.y * sinAngle;

    tmp.m_value[4] =  axe.x * axe.y * cosAngle1 + axe.z * sinAngle;
    tmp.m_value[5] =  axe.y * axe.y * cosAngle1 + cosAngle;
    tmp.m_value[6] =  axe.y * axe.z * cosAngle1 - axe.x * sinAngle;

    tmp.m_value[8] =  axe.x * axe.z * cosAngle1 - axe.y * sinAngle;
    tmp.m_value[9] =  axe.y * axe.z * cosAngle1 + axe.x * sinAngle;
    tmp.m_value[10] = axe.z * axe.z * cosAngle1 + cosAngle;

    tmp.m_value[15] = 1.0f;

    *this = *this * tmp;
}

void OMat4::rotate(float angle, float x, float y, float z)
{
    OVec3_f axe(x, y, z);
    rotate(angle, axe);
}

void OMat4::scale(float x, float y, float z)
{
    OMat4 tmp;

    tmp.m_value[0] = x;
    tmp.m_value[5] = y;
    tmp.m_value[10] = z;
    tmp.m_value[15] = 1.0f;

    *this = *this * tmp;
}

void OMat4::scale(float xyz)
{
    scale(xyz, xyz, xyz);
}
void OMat4::scale(const OVec3_f& v3)
{
    scale(v3.x, v3.y, v3.z);
}

void OMat4::setValue(int position, float value)
{
    if (position < 0 || position > 15) return;

    m_value[position] = value;
}

void OMat4::translate(float x, float y, float z)
{
    OMat4 tmp;
    tmp.loadIdentity();

    tmp.m_value[3] = x;
    tmp.m_value[7] = y;
    tmp.m_value[11] = z;

    *this = *this * tmp;
}

void OMat4::translate(int x, int y, int z)
{
	OMat4 tmp;
	tmp.loadIdentity();

	tmp.m_value[3] = static_cast<float>(x);
	tmp.m_value[7] = static_cast<float>(y);
	tmp.m_value[11] = static_cast<float>(z);

	*this = *this * tmp;
}

void OMat4::translate(const OVec3_f& v3)
{
	OMat4 tmp;
	tmp.loadIdentity();

	tmp.m_value[3] = v3.x;
	tmp.m_value[7] = v3.y;
	tmp.m_value[11] = v3.z;

	*this = *this * tmp;
}

void OMat4::transpose()
{
	OMat4 result;

	result.m_value[0]  = m_value[0];
	result.m_value[1]  = m_value[4];
	result.m_value[2]  = m_value[8];
	result.m_value[3]  = m_value[12];
	result.m_value[4]  = m_value[1];
	result.m_value[5]  = m_value[5];
	result.m_value[6]  = m_value[9];
	result.m_value[7]  = m_value[13];
	result.m_value[8]  = m_value[2];
	result.m_value[9]  = m_value[6];
	result.m_value[10] = m_value[10];
	result.m_value[11] = m_value[14];
    result.m_value[12] = m_value[3];
    result.m_value[13] = m_value[7];
    result.m_value[14] = m_value[11];
    result.m_value[15] = m_value[15];

	*this = result;
}

