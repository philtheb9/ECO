
#include "OMesh.h"

//static OTextureList textureList; //conteneur texture commun � tous les meshs

static std::string	p_path = "donnees/mesh/";
static bool         p_vao = true;
//static bool         p_mipmap = false;
//static int          p_normal = 0; //null=0 smoth
//static OVec3_f      p_scale(1.0f, 1.0f, 1.0f);
//static bool         p_error = false;



// -----------------------
// --- le constructeur ---
// -----------------------

OMesh::OMesh()
{
    m_path = "";
    m_file = "";
    m_numInstances = 0;
}

// ----------------------
// --- le destructeur ---
// ----------------------

OMesh::~OMesh()
{
    clear();
}

// --------------------
// --- les m�thodes ---
// --------------------

void OMesh::clear()
{
    m_path = "";
    m_file = "";
    m_numInstances = 0;

    OLoader_obj::P_clear_texture( material);

    // efface les textures associ�es � l'objet si plus utilis�es
    //OLoader_obj::clear(objet);

    for (size_t i = 0; i < objet.size(); i++)
    {
        if (objet[i].vertexBuffer != 0) glDeleteBuffers(1, &objet[i].vertexBuffer);
        if (objet[i].indexBuffer != 0) glDeleteBuffers(1, &objet[i].indexBuffer);

        objet[i].vertexBuffer = 0;
        objet[i].indexBuffer = 0;

        if (objet[i].vao != 0)
        {
            glDeleteBuffers(ECO_sizeOf(objet[i].buffer), objet[i].buffer);

            glDeleteVertexArrays(1, &objet[i].vao);
            objet[i].vao = 0;
        }
    }

    bornage.clear();
    material.clear();
    objet.clear();
}

/*
passage du nom du fichier depuis -> path d�fini
*/
bool OMesh::create(std::string file)
{
    if (file.find(".obj") != std::string::npos)
    {
        OLoader_obj loader;

        clear();

        m_path = ECO_fileGetPath(p_path + file);    //repertoire (pour trouver les textures et fichiers associ�s)
        m_file = ECO_fileGetName(file);         //
        //ECO_error_set("OMesh.create : path = %s", m_path.c_str());
        //ECO_error_set("OMesh.create : file = %s", m_file.c_str());

        if (!loader.load(m_path, m_file, objet, material, bornage))
        {
            clear();
            return false;
        }

        if (p_vao) _make_vao_multi(); else _make_vi();

        return true;
    }

    return false;
}


// --- draw avec vao --- (base)

// pas de clip !
void OMesh::draw()
{
    for (size_t part = 0; part < objet.size(); part++)
    {
        glBindVertexArray(objet[part].vao);

        glActiveTexture(GL_TEXTURE2);
        glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_specular);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_bump);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_color);

        uint32_t cpt = 0;

        switch (objet[part].topologie_style)
        {
        case TOP_TRIANGLE:
            glDrawElements(GL_TRIANGLES, objet[part].indice.size(), GL_UNSIGNED_INT, 0);
            break;
        case TOP_QUAD:
            glDrawElements(GL_QUADS, objet[part].indice.size(), GL_UNSIGNED_INT, 0);
            break;
        default:
            // nombre de faces
            for (size_t f = 0; f < objet[part].topologie.size(); f++)
            {
                // m_topologie[f] = points/sommets par face
                glDrawElements(GL_POLYGON, objet[part].topologie[f], GL_UNSIGNED_INT, (void*)(sizeof(uint32_t) * cpt) );
                cpt += objet[part].topologie[f];
            }
            break;
        }
    }

    //d�sactivation du VAO
    glBindVertexArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
}

// clip possible pour chaque partie
void OMesh::draw(size_t part)
{
    glBindVertexArray(objet[part].vao);

    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_specular);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_bump);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_color);

    uint32_t cpt = 0;

    switch (objet[part].topologie_style)
    {
    case TOP_TRIANGLE:
        glDrawElements(GL_TRIANGLES, objet[part].indice.size(), GL_UNSIGNED_INT, 0);
        break;
    case TOP_QUAD:
        glDrawElements(GL_QUADS, objet[part].indice.size(), GL_UNSIGNED_INT, 0);
        break;
    default:
        // nombre de faces
        for (size_t f = 0; f < objet[part].topologie.size(); f++)
        {
            // m_topologie[f] = points/sommets par face
            glDrawElements(GL_POLYGON, objet[part].topologie[f], GL_UNSIGNED_INT, (void*)(sizeof(uint32_t) * cpt) );
            cpt += objet[part].topologie[f];
        }
        break;
    }

    // + end_draw_part() !!!
}
/*
void OMesh::draw_color(size_t part)
{
    //for (size_t part = 0; part < objet.size(); part++)
    //{
        glBindVertexArray(objet[part].vao);

        //glActiveTexture(GL_TEXTURE2);
        //glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_specular);
        //glActiveTexture(GL_TEXTURE1);
        //glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_bump);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_color);

        uint32_t cpt = 0;

        switch (objet[part].topologie_style)
        {
        case TOP_TRIANGLE:
            glDrawElements(GL_TRIANGLES, objet[part].indice.size(), GL_UNSIGNED_INT, 0);
            break;
        case TOP_QUAD:
            glDrawElements(GL_QUADS, objet[part].indice.size(), GL_UNSIGNED_INT, 0);
            break;
        case TOP_POLYGON:
            // nombre de faces
            for (size_t f = 0; f < objet[part].topologie.size(); f++)
            {
                // m_topologie[f] = points/sommets par face
                glDrawElements(GL_POLYGON, objet[part].topologie[f], GL_UNSIGNED_INT, (void*)(sizeof(uint32_t) * cpt) );
                cpt += objet[part].topologie[f];
            }
            break;
        }
    //}

    //d�sactivation du VAO
    //glBindVertexArray(0);
    //glBindBuffer(GL_ARRAY_BUFFER, 0);
}
*/
/*
void OMesh::draw_color()
{
    for (size_t part = 0; part < objet.size(); part++)
    {
        glBindVertexArray(objet[part].vao);

        //glActiveTexture(GL_TEXTURE2);
        //glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_specular);
        //glActiveTexture(GL_TEXTURE1);
        //glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_bump);
        //glActiveTexture(GL_TEXTURE0);
        //glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_color);

        uint32_t cpt = 0;

        switch (objet[part].topologie_style)
        {
        case TOP_TRIANGLE:
            glDrawElements(GL_TRIANGLES, objet[part].indice.size(), GL_UNSIGNED_INT, 0);
            break;
        case TOP_QUAD:
            glDrawElements(GL_QUADS, objet[part].indice.size(), GL_UNSIGNED_INT, 0);
            break;
        case TOP_POLYGON:
            // nombre de faces
            for (size_t f = 0; f < objet[part].topologie.size(); f++)
            {
                // m_topologie[f] = points/sommets par face
                glDrawElements(GL_POLYGON, objet[part].topologie[f], GL_UNSIGNED_INT, (void*)(sizeof(uint32_t) * cpt) );
                cpt += objet[part].topologie[f];
            }
            break;
        }
    }

    //d�sactivation du VAO
    glBindVertexArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
}
*/
/*
ne pas activer la texture
> pour ODshLightPoint
> pick color
> ...
*/
void OMesh::draw_no_texture()
{
    //glDisable(GL_TEXTURE);

    for (size_t part = 0; part < objet.size(); part++)
    {
        glBindVertexArray(objet[part].vao);

        //glActiveTexture(GL_TEXTURE2);
        //glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_specular);
        //glActiveTexture(GL_TEXTURE1);
        //glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_bump);
        //glActiveTexture(GL_TEXTURE0);
        //glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_color);

        uint32_t cpt = 0;

        switch (objet[part].topologie_style)
        {
        case TOP_TRIANGLE:
            glDrawElements(GL_TRIANGLES, objet[part].indice.size(), GL_UNSIGNED_INT, 0);
            break;
        case TOP_QUAD:
            glDrawElements(GL_QUADS, objet[part].indice.size(), GL_UNSIGNED_INT, 0);
            break;
        default:
            // nombre de faces
            for (size_t f = 0; f < objet[part].topologie.size(); f++)
            {
                // m_topologie[f] = points/sommets par face
                glDrawElements(GL_POLYGON, objet[part].topologie[f], GL_UNSIGNED_INT, (void*)(sizeof(uint32_t) * cpt) );
                cpt += objet[part].topologie[f];
            }
            break;
        }
    }

    //d�sactivation du VAO
    glBindVertexArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
}


void OMesh::draw_line()
{
    for (size_t part = 0; part < objet.size(); part++)
    {
        glBindVertexArray(objet[part].vao);

        //glActiveTexture(GL_TEXTURE2);
        //glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_specular);
        //glActiveTexture(GL_TEXTURE1);
        //glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_bump);
        //glActiveTexture(GL_TEXTURE0);
        //glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_color);

        uint32_t cpt = 0;

        // nombre de faces
        for (size_t f = 0; f < objet[part].topologie.size(); f++)
        {
            // m_topologie[f] = points/sommets par face
            glDrawElements(GL_LINE_STRIP, objet[part].topologie[f], GL_UNSIGNED_INT, (void*)(sizeof(uint32_t) * cpt) );
            cpt += objet[part].topologie[f];
        }
    }

    //d�sactivation du VAO
    glBindVertexArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void OMesh::draw_line(size_t part)
{
    //for (size_t part = 0; part < objet.size(); part++)
    //{
        glBindVertexArray(objet[part].vao);

        //glActiveTexture(GL_TEXTURE2);
        //glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_specular);
        //glActiveTexture(GL_TEXTURE1);
        //glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_bump);
        //glActiveTexture(GL_TEXTURE0);
        //glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_color);

        uint32_t cpt = 0;

        // nombre de faces
        for (size_t f = 0; f < objet[part].topologie.size(); f++)
        {
            // m_topologie[f] = points/sommets par face
            glDrawElements(GL_LINE_STRIP, objet[part].topologie[f], GL_UNSIGNED_INT, (void*)(sizeof(uint32_t) * cpt) );
            cpt += objet[part].topologie[f];
        }
    //}

    //d�sactivation du VAO
    //glBindVertexArray(0);
    //glBindBuffer(GL_ARRAY_BUFFER, 0);
}



// ---

/*
avec OShColor3d / volume ou picking
*/
void OMesh::draw_multi_color(size_t part)
{
    //for (size_t part = 0; part < objet.size(); part++)
    //{
        glBindVertexArray(objet[part].vao);

        //glActiveTexture(GL_TEXTURE2);
        //glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_specular);
        //glActiveTexture(GL_TEXTURE1);
        //glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_bump);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_color);

        uint32_t cpt = 0;

        switch (objet[part].topologie_style)
        {
        case TOP_TRIANGLE:
            //(GLenum mode, GLsizei count, GLenum type, const void* indices, GLsizei primcount);
            glDrawElementsInstanced(GL_TRIANGLES, objet[part].indice.size(), GL_UNSIGNED_INT, 0, m_numInstances);
            break;
        case TOP_QUAD:
            glDrawElementsInstanced(GL_QUADS, objet[part].indice.size(), GL_UNSIGNED_INT, 0, m_numInstances);
            break;
        default:
            // nombre de faces
            for (size_t f = 0; f < objet[part].topologie.size(); f++)
            {
                // m_topologie[f] = points/sommets par face
                glDrawElementsInstanced(GL_POLYGON, objet[part].topologie[f], GL_UNSIGNED_INT, (void*)(sizeof(uint32_t) * cpt), m_numInstances);
                cpt += objet[part].topologie[f];
            }
            break;
        }
    //}

    //d�sactivation du VAO
    //glBindVertexArray(0);
    //glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void OMesh::draw_multi_line(size_t part)
{
    //for (size_t part = 0; part < objet.size(); part++)
    //{
        glBindVertexArray(objet[part].vao);

        //glActiveTexture(GL_TEXTURE2);
        //glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_specular);
        //glActiveTexture(GL_TEXTURE1);
        //glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_bump);
        //glActiveTexture(GL_TEXTURE0);
        //glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_color);

        uint32_t cpt = 0;

        // nombre de faces
        for (size_t f = 0; f < objet[part].topologie.size(); f++)
        {
            // m_topologie[f] = points/sommets par face
            glDrawElementsInstanced(GL_LINE_STRIP, objet[part].topologie[f], GL_UNSIGNED_INT, (void*)(sizeof(uint32_t) * cpt), m_numInstances);
            cpt += objet[part].topologie[f];
        }

        // rendu moins bon
        //glDrawElementsInstanced(GL_LINE_STRIP, objet[part].indice.size(), GL_UNSIGNED_INT, 0, m_numInstances);
    //}

    //d�sactivation du VAO
    //glBindVertexArray(0);
    //glBindBuffer(GL_ARRAY_BUFFER, 0);
}

/*
void OMesh::draw_vi(size_t part)
{
    glEnableVertexAttribArray(0);
    glEnableVertexAttribArray(1);
    glEnableVertexAttribArray(2);

    glBindBuffer(GL_ARRAY_BUFFER, objet[part].vertexBuffer);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Sobj_sommet), 0);                // vertex
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(Sobj_sommet), (const void*)12);  // uv / +3 * (4 octets par float)
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, sizeof(Sobj_sommet), (const void*)20);  // normal

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, objet[part].indexBuffer);

    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_specular);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_bump);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_color);

    // --- quad ---

    // (GLenum mode, GLsizei count, GLenum type, const void *indices);
    // dessine le cube
    //glDrawElements(GL_QUADS, m_indice.size(), GL_UNSIGNED_INT, 0);

    // dessine le dessus
    //glDrawElements(GL_QUADS, 4, GL_UNSIGNED_INT, (void*)(sizeof(uint32_t) * 12) );

    // --- triangles ---

    //glDrawElements(GL_TRIANGLES, m_indice.size(), GL_UNSIGNED_INT, 0);

    //for (size_t f = 0; f < 6*2; f++)
    //{
    //    glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_INT, (void*)(sizeof(uint32_t) * f*3) );
    //}

    // --- mixe ---

    uint32_t cpt = 0;
    // nombre de faces
    for (size_t f = 0; f < objet[part].topologie.size(); f++)
    {
        // m_topologie[f] = points/sommets par face
        glDrawElements(GL_POLYGON, objet[part].topologie[f], GL_UNSIGNED_INT, (void*)(sizeof(uint32_t) * cpt) );
        cpt += objet[part].topologie[f];
    }

    glDisableVertexAttribArray(0);
    glDisableVertexAttribArray(1);
    glDisableVertexAttribArray(2);

    // end_draw_part()
}
*/

void OMesh::draw_multi(size_t part)
{
    glBindVertexArray(objet[part].vao);

    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_specular);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_bump);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, material[ objet[part].material ].tex_color);

    uint32_t cpt = 0;

    switch (objet[part].topologie_style)
    {
    case TOP_TRIANGLE:
        //(GLenum mode, GLsizei count, GLenum type, const void* indices, GLsizei primcount);
        glDrawElementsInstanced(GL_TRIANGLES, objet[part].indice.size(), GL_UNSIGNED_INT, 0, m_numInstances);
        break;
    case TOP_QUAD:
        glDrawElementsInstanced(GL_QUADS, objet[part].indice.size(), GL_UNSIGNED_INT, 0, m_numInstances);
        break;
    default:
        // nombre de faces
        for (size_t f = 0; f < objet[part].topologie.size(); f++)
        {
            // m_topologie[f] = points/sommets par face
            glDrawElementsInstanced(GL_POLYGON, objet[part].topologie[f], GL_UNSIGNED_INT, (void*)(sizeof(uint32_t) * cpt), m_numInstances);
            cpt += objet[part].topologie[f];
        }
        break;
    }

    //d�sactivation du VAO dans end_draw_part()
}

void OMesh::end_draw_part()
{
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);

    glBindTexture(GL_TEXTURE_2D, 0);
    glActiveTexture(GL_TEXTURE0);
}




float OMesh::getAlpha(size_t part)
{
    return material[ objet[part].material ].alpha;
}

void OMesh::getBound(OVec3_f& bound_min, OVec3_f& bound_max)
{
    OVec3_f part_min, part_max;

    bound_min.set(10000.0f, 10000.0f, 10000.0f);
    bound_max.set(-10000.0f, -10000.0f, -10000.0f);

    for (size_t part = 0; part < objet.size(); part++)
    {
        for (size_t s = 0; s < objet[part].sommet.size(); s++)
        {
            if (objet[part].sommet[s].vertex.x < bound_min.x) bound_min.x = objet[part].sommet[s].vertex.x;
            if (objet[part].sommet[s].vertex.y < bound_min.y) bound_min.y = objet[part].sommet[s].vertex.y;
            if (objet[part].sommet[s].vertex.z < bound_min.z) bound_min.z = objet[part].sommet[s].vertex.z;

            if (objet[part].sommet[s].vertex.x > bound_max.x) bound_max.x = objet[part].sommet[s].vertex.x;
            if (objet[part].sommet[s].vertex.y > bound_max.y) bound_max.y = objet[part].sommet[s].vertex.y;
            if (objet[part].sommet[s].vertex.z > bound_max.z) bound_max.z = objet[part].sommet[s].vertex.z;
        }
    }
}

uint32_t OMesh::getBumpMap(size_t part)
{
    return material[ objet[part].material ].tex_color;
}

float OMesh::getScaleNormal(size_t part)
{
    return material[ objet[part].material ].tex_param.multBump;
}

bool OMesh::getClip(size_t part)
{
    return material[ objet[part].material ].clip;
}

uint32_t OMesh::getColorMap(size_t part)
{
    return material[ objet[part].material ].tex_bump;
}

OVec4_f OMesh::getDiffuse(size_t part)
{
    OVec4_f result;

    result.r = material[ objet[part].material ].Kd[0];
    result.g = material[ objet[part].material ].Kd[1];
    result.b = material[ objet[part].material ].Kd[2];
    result.a = material[ objet[part].material ].Kd[3];

    return result;
}

size_t OMesh::getNbPart()
{
    return objet.size();
}

uint32_t OMesh::getSpecularMap(size_t part)
{
    return material[ objet[part].material ].tex_specular;
}





void OMesh::_make_vi()
{
    for (size_t part = 0; part < objet.size(); part++)
    {
        glGenBuffers(1, &objet[part].vertexBuffer);
        glBindBuffer(GL_ARRAY_BUFFER, objet[part].vertexBuffer);
        glBufferData(GL_ARRAY_BUFFER, sizeof(Sobj_sommet) * objet[part].sommet.size(), &objet[part].sommet[0], GL_STATIC_DRAW);

        glGenBuffers(1, &objet[part].indexBuffer);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, objet[part].indexBuffer);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(unsigned int) * objet[part].indice.size(), &objet[part].indice[0], GL_STATIC_DRAW);
    }
}

void OMesh::_make_vao()
{
    for (size_t part = 0; part < objet.size(); part++)
    {
        //g�n�ration de l'identifiant du VAO
        glGenVertexArrays(1, &objet[part].vao);
        //activation du VAO
        glBindVertexArray(objet[part].vao);

        // vertex buffer
        glGenBuffers(1, &objet[part].vertexBuffer);
        glBindBuffer(GL_ARRAY_BUFFER, objet[part].vertexBuffer);
        glBufferData(GL_ARRAY_BUFFER, sizeof(Sobj_sommet) * objet[part].sommet.size(), &objet[part].sommet[0], GL_STATIC_DRAW);

        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Sobj_sommet), 0);                // vertex
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(Sobj_sommet), (const void*)12);  // uv / +3 * (4 octets par float)
        glEnableVertexAttribArray(1);
        glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, sizeof(Sobj_sommet), (const void*)20);  // normal
        glEnableVertexAttribArray(2);

        // index buffer
        glGenBuffers(1, &objet[part].indexBuffer);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, objet[part].indexBuffer);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(unsigned int) * objet[part].indice.size(), &objet[part].indice[0], GL_STATIC_DRAW);
    }

    //glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
}

void OMesh::_make_vao_multi()
{
    //std::vector<OVec3_f> vertex;
    //std::vector<OVec2_f> uv;
    //std::vector<OVec3_f> normal;

    //size_t vertexBytes = 0;
    //size_t uvBytes = 0;
    //size_t normalBytes = 0;

    for (size_t part = 0; part < objet.size(); part++)
    {
/*
        // --- recuperation des donn�es
        vertex.clear();
        uv.clear();
        normal.clear();

        vertex.reserve( objet[part].sommet.size() );
        uv.reserve( objet[part].sommet.size() );
        normal.reserve( objet[part].sommet.size() );

        for (size_t i = 0; i < objet[part].sommet.size(); i++)
        {
            vertex.push_back( objet[part].sommet[i].vertex);
            uv.push_back( objet[part].sommet[i].uv);
            normal.push_back( objet[part].sommet[i].normal);
        }
        vertexBytes = vertex.size() * sizeof(OVec3_f);
        uvBytes = uv.size() * sizeof(OVec2_f);
        normalBytes = normal.size() * sizeof(OVec3_f);
*/
        // --- g�n�ration du VAO
        glGenVertexArrays(1, &objet[part].vao);
        //activation du VAO
        glBindVertexArray(objet[part].vao);
        //g�n�ration des buffers
        glGenBuffers(ECO_sizeOf(objet[part].buffer), objet[part].buffer);
        //
        // vertex buffer
        glGenBuffers(1, &objet[part].vertexBuffer);
        glBindBuffer(GL_ARRAY_BUFFER, objet[part].vertexBuffer);
        glBufferData(GL_ARRAY_BUFFER, sizeof(Sobj_sommet) * objet[part].sommet.size(), &objet[part].sommet[0], GL_STATIC_DRAW);

        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Sobj_sommet), 0);                // vertex
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(Sobj_sommet), (const void*)12);  // uv / +3 * (4 octets par float)
        glEnableVertexAttribArray(1);
        glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, sizeof(Sobj_sommet), (const void*)20);  // normal
        glEnableVertexAttribArray(2);
/*
        glBindBuffer(GL_ARRAY_BUFFER, objet[part].buffer[BUF_VERTEX]);
        glBufferData(GL_ARRAY_BUFFER, vertexBytes, &vertex[0], GL_STATIC_DRAW);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);
        //glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Sobj_sommet), 0);

        glBindBuffer(GL_ARRAY_BUFFER, objet[part].buffer[BUF_UV]);
        glBufferData(GL_ARRAY_BUFFER, uvBytes, &uv[0], GL_STATIC_DRAW);
        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 0, 0);
        //glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(Sobj_sommet), (const void*)12);

        glBindBuffer(GL_ARRAY_BUFFER, objet[part].buffer[BUF_NORMAL]);
        glBufferData(GL_ARRAY_BUFFER, normalBytes, &normal[0], GL_STATIC_DRAW);
        glEnableVertexAttribArray(2);
        glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 0, 0);
        //glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, sizeof(Sobj_sommet), (const void*)20);
*/
        glBindBuffer(GL_ARRAY_BUFFER, objet[part].buffer[BUF_MODEL]); // 4 �l�ments dans chaque
        for (int i = 0; i < 4 ; i++)
        {
            glEnableVertexAttribArray(BUF_MODEL + i);
            glVertexAttribPointer(BUF_MODEL + i, 4, GL_FLOAT, GL_FALSE, sizeof(OMat4), (const void*)(sizeof(float) * i * 4));
            glVertexAttribDivisor(BUF_MODEL + i, 1);
        }

        // index buffer
        glGenBuffers(1, &objet[part].indexBuffer);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, objet[part].indexBuffer);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(unsigned int) * objet[part].indice.size(), &objet[part].indice[0], GL_STATIC_DRAW);

        //d�sactivation du VAO
        //glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
        glBindBuffer(GL_ARRAY_BUFFER, 0);
        glBindVertexArray(0);
    }
}



void OMesh::setModelMulti(std::vector<OMat4>& modelMulti)
{
	m_numInstances = modelMulti.size();

    for (size_t part = 0; part < objet.size(); part++)
    {
        glBindVertexArray(objet[part].vao);
        glBindBuffer(GL_ARRAY_BUFFER, objet[part].buffer[BUF_MODEL]);
        glBufferData(GL_ARRAY_BUFFER, sizeof(OMat4) * m_numInstances, &modelMulti[0], GL_DYNAMIC_DRAW);
    }

    //d�sactivation du VAO
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
}



// ----------------------
// --- les propri�t�s ---
// ----------------------

void OMesh::P_setMipmap(bool mode)
{
    OLoader_obj::P_setMipmap(mode);
}

void OMesh::P_setPath(std::string path)
{
    p_path = path;
}

// scale des objets charg�s
void OMesh::P_setScale(float sx, float sy, float sz)
{
    OLoader_obj::P_setScale(sx, sy, sz);
}

void OMesh::P_setScale(OVec3_f& scale)
{
    OLoader_obj::P_setScale(scale.x, scale.y, scale.z);
}

void OMesh::P_setVao(bool mode)
{
    p_vao = mode;
}







