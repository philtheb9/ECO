#ifndef OVEC3_H_INCLUDED
#define OVEC3_H_INCLUDED

/*
OBJET       classe d'un vecteur 3d GLfloat

DATE        12/2017

AUTEUR      philippe Thebaud

COMMENTAIRE
*/

#include <cmath>
#include <GL/glew.h>
#include <GL/wglew.h>


//les structures statiques
struct SVec3_i { int x; int y; int z; };
struct SVec3_f { float x; float y; float z; };
struct SVec3_d { double x; double y; double z; };


template <class T> class OVec3
{
public:

	union{
		struct{T x, y, z;};
		struct{T r, g, b;};
	};

    OVec3() {x=0;y=0;z=0;}
    OVec3(const T vx, const T vy, const T vz) { x=vx; y=vy; z=vz; }


    void    set(const T vx, const T vy, const T vz)
    {
        x = vx;
        y = vy;
        z = vz;
    }
    void    set(const T v[3])
    {
        x = v[0];
        y = v[1];
        z = v[2];
    }
    void    set(const OVec3& v3)
    {
        x = v3.x;
        y = v3.y;
        z = v3.z;
    }


    bool operator == (const OVec3& v3)
    {
        return (x == v3.x && y == v3.y && z == v3.z);
    }
    bool operator != (const OVec3& v3) const
    {
        return (x != v3.x || y != v3.y || z != v3.z);
    }
    bool operator <= (const OVec3& v3) const
    {
        return (x <= v3.x && y <= v3.y && z <= v3.z);
    }
    bool operator >= (const OVec3& v3) const
    {
        return (x >= v3.x && y >= v3.y && z >= v3.z);
    }


    OVec3& operator = (const OVec3& v3)
    {
        x = v3.x;
        y = v3.y;
        z = v3.z;
        return *this;
    }
    //pour transfert des données
    OVec3& operator = (const SVec3_f& v3)
    {
        x = v3.x;
        y = v3.y;
        z = v3.z;
        return *this;
    }
    OVec3& operator = (const SVec3_i& v3)
    {
        x = v3.x;
        y = v3.y;
        z = v3.z;
        return *this;
    }



    OVec3 operator + (const OVec3& v3)
    {
        OVec3 result;
        result.x = x + v3.x;
        result.y = y + v3.y;
        result.z = z + v3.z;
        return result;
    }
    OVec3 operator - (const OVec3& v3)
    {
        OVec3 result;
        result.x = x - v3.x;
        result.y = y - v3.y;
        result.z = z - v3.z;
        return result;
    }
    OVec3 operator * (const OVec3& v3)
    {
        OVec3 result(x*v3.x, y*v3.y, z*v3.z);
        return result;
    }
    //cross
    OVec3 operator ^ (const OVec3& v3)
    {
        OVec3 result;
        result.x = (y * v3.z) - (z * v3.y);
        result.y = (z * v3.x) - (x * v3.z);
        result.z = (x * v3.y) - (y * v3.x);

        return result;
    }
    OVec3 operator / (const OVec3& v3)
    {
        OVec3 result(0,0,0);
        if (v3.x*v3.y*v3.z == 0) return result;
        result.set(x/v3.x, y/v3.y, z/v3.z);
        return result;
    }

    void operator += (const OVec3& v3)
    {
        x += v3.x;
        y += v3.y;
        z += v3.z;
        //return *this;
    }

    void operator -= (const OVec3& v3)
    {
        x -= v3.x;
        y -= v3.y;
        z -= v3.z;
        //return *this;
    }

    void operator *= (const OVec3& v3)
    {
        x *= v3.x;
        y *= v3.y;
        z *= v3.z;
        //return *this;
    }

    void operator /= (const OVec3& v3)
    {
        if (v3.x == 0 | v3.y == 0 | v3.z == 0) return;
        x /= v3.x;
        y /= v3.y;
        z /= v3.z;
        //return *this;
    }



    OVec3 operator / (const T value)
    {
        OVec3 result(0,0,0);
        if (value == 0) return result;
        result.x = x / value;
        result.y = y / value;
        result.z = z / value;
        return result;
    }

    OVec3 operator * (const T value)
    {
        OVec3 result;
        result.x = x * value;
        result.y = y * value;
        result.z = z * value;
        return result;
    }

    OVec3 operator + (const T value)
    {
        OVec3 result;
        result.x = x + value;
        result.y = y + value;
        result.z = z + value;
        return result;
    }

    OVec3 operator - (const T value)
    {
        OVec3 result;
        result.x = x - value;
        result.y = y - value;
        result.z = z - value;
        return result;
    }



    void operator *= (const T value)
    {
        x *= value;
        y *= value;
        z *= value;
    }

    void operator /= (const T value)
    {
        if (value == 0) return;
        x /= value;
        y /= value;
        z /= value;
    }

    void operator += (const T value)
    {
        x += value;
        y += value;
        z += value;
    }

    void operator -= (const T value)
    {
        x -= value;
        y -= value;
        z -= value;
    }




/*
    OVec3   operator()(T vx, T vy, T vz)
    {
        x = vx;
        y = vy;
        z = vz;
        return *this;
    }
*/


// --------------------
// --- les méthodes ---
// --------------------

    OVec3 cross(const OVec3& v0, const OVec3& v1)
    {
        x = (v0.y * v1.z) - (v0.z * v1.y);
        y = (v0.z * v1.x) - (v0.x * v1.z);
        z = (v0.x * v1.y) - (v0.y * v1.x);

        return *this; //OVec3(x,y,z);
    }

    T   dot(const OVec3& v3) const
    {
        return x*v3.x + y*v3.y + z*v3.z;
    }
    T   dot(const OVec3& v0, const OVec3& v1) const
    {
        return v0.x*v1.x + v0.y*v1.y + v0.z*v1.z;
    }
    T   length(OVec3& v0, OVec3& v1) const
    {
        return sqrt((v0.x*v1.x)+(v0.y*v1.y)+(v0.z*v1.z));
    }
    T   length(OVec3& v3) const
    {
        return sqrt((x*v3.x)+(y*v3.y)+(z*v3.z));
    }
    T   length() const
    {
        return sqrt((x*x)+(y*y)+(z*z));
    }

    void normalize()
    {
        T lg = sqrtf(x*x + y*y + z*z);
        if (lg > 0)
        {
            const T a = 1.0 / lg; //1 seule division lente
            x *= a;
            y *= a;
            z *= a;
        }
    }
    OVec3 normalized() const
    {
        OVec3 result(*this);
        result.normalize();
        return result;
    }
/*
calcul complet de normal par passage de 3 vecteurs
soit  : OVector vecteur[3]={{1,0,34},{3,45,2},{23,12,4}};
alors : vnormal.getNormal(vecteur);
        gNormal(vnormal.x, vnormal.y, vnormal.z);
Attention l'ordre dans lequel on passe les parametre est important, il indique le sens du reflet.
*/
    void normalize(const OVec3 v[])
    {
        OVec3 result;
        float v1x = (v[2].x - v[0].x);
        float v1y = (v[2].y - v[0].y);
        float v1z = (v[2].z - v[0].z);

        float v2x = (v[1].x - v[0].x);
        float v2y = (v[1].y - v[0].y);
        float v2z = (v[1].z - v[0].z);

        result.x = (v1y * v2z) - (v1z * v2y);
        result.y = (v1z * v2x) - (v1x * v2z);
        result.z = (v1x * v2y) - (v1y * v2x);
        result.normalize();

        x = result.x;
        y = result.y;
        z = result.z;
    }

    void rotateX(float angle)
    {
        const float DEGTORAD = 0.0174532925199f;
        if (angle == 0.0f) return;
        float sinAngle = sin(angle * DEGTORAD);
        float cosAngle = cos(angle * DEGTORAD);
        float y1 = y, z1 = z;

        y = y1*cosAngle - z1*sinAngle;
		z = y1*sinAngle + z1*cosAngle;
    }

    void rotateY(float angle)
    {
        const float DEGTORAD = 0.0174532925199f;
        if (angle == 0.0f) return;
        float sinAngle = sin(angle * DEGTORAD);
        float cosAngle = cos(angle * DEGTORAD);
        float x1 = x, z1 = z;

        x = x1*cosAngle + z1*sinAngle;
        z = -x1*sinAngle + z1*cosAngle;
    }

    void rotateZ(float angle)
    {
        const float DEGTORAD = 0.0174532925199f;
        if (angle == 0.0f) return;
        float sinAngle = sin(angle * DEGTORAD);
        float cosAngle = cos(angle * DEGTORAD);
        float x1 = x, y1 = y;

        x = x1*cosAngle - y1*sinAngle;
        y = x1*sinAngle + y1*cosAngle;
    }

/*
    // mauvais
    T angleDegs(const OVec3& v3) const
    {
        T len = length();
        T vlen = v3.length();
        if (len == 0 || vlen == 0)
            return NULL;
        return acos(dot(v3)/(len*vlen)) * (180.0f/3.14159265358979323846);
    }

    T angleRads(const OVec3& v3) const
    {
        T len = length();
        T vlen = v3.length();
        if (len == 0 || vlen == 0)
            return NULL;
        return acos(dot(v3)/(len*vlen));
    }
*/
};

typedef OVec3<float>    OVec3_f;
typedef OVec3<double>   OVec3_d;
typedef OVec3<int>      OVec3_i;
typedef OVec3<uint32_t> OVec3_ui;
typedef OVec3<size_t>   OVec3_s;

//le vec null (pour passage de null en paramatètre par defaut dans une fonction)
static OVec3_i  OVEC3I_NULL(0,0,0);
static OVec3_f  OVEC3F_NULL(0,0,0);
static OVec3_d  OVEC3D_NULL(0,0,0);
static OVec3_ui OVEC3UI_NULL(0,0,0);



#endif
