#include "OSurface.h"

// -------------------
// -- constructeur ---
// -------------------

OSurface::OSurface()
{
	m_pixels = NULL;
	clear();
}

OSurface::OSurface(const OSurface &copy)
{
	m_pixels = NULL;
	clear();

    if (copy.exist())
    {
		//accès aux attributs dans la même classe
		m_width = copy.m_width;
		m_height = copy.m_height;
		m_bpp = copy.m_bpp;
		m_pitch = copy.m_pitch;
		m_format = copy.m_format;

		m_pixels = new uint8_t[m_pitch * m_height];
		memcpy(m_pixels, copy.m_pixels, m_pitch * m_height);
    }
}

// -------------------
// --- destructeur ---
// -------------------

OSurface::~OSurface()
{
    clear();
}

// -----------------
// --- opérateur ---
// -----------------

OSurface &OSurface::operator= (const OSurface &surface)
{
    if (this != &surface)
    {
        clear();

        if (surface.exist())
        {
        	//accès aux attributs dans la même classe
            m_width = surface.m_width;
            m_height = surface.m_height;
            m_bpp = surface.m_bpp;
            m_pitch = surface.m_pitch;
			m_format = surface.m_format;

            m_pixels = new uint8_t[m_pitch * m_height];
            memcpy(m_pixels, surface.m_pixels, m_pitch * m_height);
        }
    }

    return *this;
}

// ---------------
// --- méthode ---
// ---------------

/*
création d'une surface
format GL_RGB GL_RGBA GL_BGR GL_BGRA
*/
void OSurface::create(int width, int height, int byteperpixel, int format)
{
    if (width < 1) return;
    if (height < 1) return;
    if (byteperpixel < 3) byteperpixel = 3;
	if (byteperpixel > 4) byteperpixel = 4;
    clear();

    m_width = width;
    m_height = height;
    m_bpp = byteperpixel;
    m_pitch = width * byteperpixel;
	m_format = format;

    m_pixels = new uint8_t[m_pitch * m_height];
    //raz
    for (int i = 0, size = m_pitch * m_height; i < size; i++)
		m_pixels[i] = 0;
}

// l'image est inversée par défaut !
bool OSurface::load(std::string filename, bool inversee)
{
	clear();

    if (filename.find(".BMP") != filename.npos || filename.find(".bmp") != filename.npos)
    {
		return _loadBMP(filename, inversee);
    }

	//if (filename.find(".TGA") != filename.npos || filename.find(".tga") != filename.npos)
	//	return _loadTGA(filename);

	if (filename.find(".PNG") != filename.npos || filename.find(".png") != filename.npos)
    {
        return _loadPNG(filename, inversee);
    }

	if (filename.find(".JPG") != filename.npos || filename.find(".jpg") != filename.npos)
    {
        return _loadJPG(filename, inversee);
    }

    //if (filename.find(".DDS") != filename.npos || filename.find(".dds") != filename.npos)
	//	return _loadDDS(filename);

	ECO_error_set( "format image de %s non reconnu >OSurface.load", filename.c_str());

	return false;
}

bool OSurface::_loadBMP(std::string filename, bool inversee)
{
	clear();

	if (!loaderBMP_load(filename, &m_bpp, &m_width, &m_height, &m_pitch, &m_pixels))
	{
        clear();
		ECO_error_set("BMP decoder error %s >OSurface.loadBMP", filename.c_str());
		return false;
	}
	if (m_bpp == 3)
	{
        m_format = GL_RGB;
    	//format bgr de bitmap = swap b and r
        for (int row = 0; row < m_height; row++)
        {
            for (int  i = 0; i < m_width; i++)
            {
                //Repeated XOR to swap bytes 0 and 2
                m_pixels[(row*m_pitch)+i*3] ^= m_pixels[(row*m_pitch)+i*3+2] ^=
                m_pixels[(row*m_pitch)+i*3] ^= m_pixels[(row*m_pitch)+i*3+2];
            }
        }
	}
    else
    {
        m_format = GL_RGBA;
        //swap b -r / applique alpha 255=opaque
        uint8_t swap;
        for (int row = 0; row < m_height; row++)
            for (int i = 0; i < m_width; i++)
            {
                swap = m_pixels[(row*m_pitch)+i*4];
                m_pixels[(row*m_pitch)+i*4] = m_pixels[(row*m_pitch)+i*4+2];
                m_pixels[(row*m_pitch)+i*4+2] = swap;

                m_pixels[(row*m_pitch)+i*4+3] = 255;
            }
    }
    if (inversee) flipV();

    return true;
}

bool OSurface::_loadJPG(std::string filename, bool inversee)
{
	clear();

	int actual_comps = 3;		// RGB
	int req_comps = 4;	// RGB = 3 / RGBA = 4 (préférable selon jpgd.h)
	int w,h;

	m_pixels = jpgd::decompress_jpeg_image_from_file(filename.c_str(), &w, &h, &actual_comps, req_comps);
	if (!m_pixels)
	{
		clear();
		ECO_error_set("JPG decoder error %s >OSurface.loadJPG", filename.c_str());
		return false;
	}

	m_width = w;
	m_height = h;
    m_bpp = 4;
    m_pitch = _calculatePitch();
    m_format = GL_RGBA;

	if (inversee) flipV();

	return true;
}

bool OSurface::_loadPNG(std::string filename, bool inversee)
{
	clear();

	//chargement 24 et 32 bits
	uint32_t w, h;
	int error = lodepng_decode32_file(&m_pixels, &w, &h, filename.c_str());
	if (error)
	{
		clear();
		ECO_error_set("PNG decoder error %s : %s >OSurface.loadPNG", lodepng_error_text(error), filename.c_str());
		return false;
	}
    m_width = w;
    m_height = h;
	m_bpp = 4;
    m_pitch = _calculatePitch();
	m_format = GL_RGBA;

	if (inversee) flipV();

	return true;
}

/*
copie d'une portion de surface vers une portion de surface destination
*/
void OSurface::blit(ORect_i& srcRect, OSurface& dstSurface, ORect_i& dstRect)
{
	ORect_i sr, dr;
	int srcx, srcy, w, h;
    int maxw, maxh;
    int dx, dy;

	// surface exist + non bloquée
	if (!exist() || !dstSurface.exist())
	{
		ECO_error_set("srcSurface ou dstSurface == NULL ! >OSurface.blit");
		return;
	}
	// *** if (srcSurface->locked || dstSurface->locked)
	//{
	//	std::cerr << "srcSurface ou dstSurface est bloquée (LockSurface) >ECO_blit" << std::endl;
	//	return;
	//}

    int srcBpp = m_bpp;
    int dstBpp = dstSurface.getBpp();

	if (!dstRect.isValid())
	{
		dr.x = dr.y = 0;
		dr.w = dstSurface.getWidth()-1;
		dr.h = dstSurface.getHeight()-1;
	}
	else
	{
		dr = dstRect;
	}

	// ajuste la source à la destination. recadre dans dstSurface
	if (srcRect.isValid())
	{
		srcx = srcRect.x;
		w = srcRect.w;
		if (srcx < 0)
		{
			w += srcx;
			dr.x -= srcx;
			srcx = 0;
		}
		maxw = m_width - srcx;
		if (maxw < w)
			w = maxw;

		srcy = srcRect.y;
		h = srcRect.h;
		if (srcy < 0)
		{
			h += srcy;
			dr.y -= srcy;
			srcy = 0;
		}
		maxh = m_height - srcy;
		if (maxh < h)
			h = maxh;
	}
	else
	{
		srcx = srcy = 0;
		w = m_width;
		h = m_height;
	}

    //SRect_i clip = {0,0,(int)dstSurface.getWidth(), (int)dstSurface.getHeight()};
    ORect_i clip(0,0, dstSurface.getWidth(), dstSurface.getHeight());
    dx = clip.x - dr.x;
    if (dx > 0)
    {
        w -= dx;
        dr.x += dx;
        srcx += dx;
    }
    dx = dr.x + w - clip.x - clip.w;
    if (dx > 0)
        w -= dx;

    dy = clip.y - dr.y;
    if (dy > 0)
    {
        h -= dy;
        dr.y += dy;
        srcy += dy;
    }
    dy = dr.y + h - clip.y - clip.h;
    if (dy > 0)
    {
        h -= dy;
    }

	if (w < 1 || h < 1) return;

    sr.x = srcx;
    sr.y = srcy;
    sr.w = dr.w = w;
    sr.h = dr.h = h;

    if (srcBpp == 3)
        if (dstBpp == 3)
            _blit_RGB_RGB(sr, dstSurface, dr);
        else
            _blit_RGB_RGBA(sr, dstSurface, dr);
    else
        if (dstBpp == 3)
            _blit_RGBA_RGB(sr, dstSurface, dr);
        else
            _blit_RGBA_RGBA(sr, dstSurface, dr);
}

//non testée
void OSurface::_blit_RGB_RGB(ORect_i& srcRect, OSurface& dstSurface, ORect_i& dstRect)
{
    int xs,ys,xd,yd;
    uint8_t *psrc, *pdst;
    uint32_t pixel;
    uint8_t R8, G8, B8;

    //(-1 pour compenser xs++ yd++ ...)
    ys = srcRect.y -1;
    yd = dstRect.y -1;

    for (int y0 = 0, y1 = srcRect.h; y0 < y1; y0++)
    {
        ys++;
        yd++;

        xs = srcRect.x -1;
        xd = dstRect.x -1;

        for (int x0 = 0, x1 = srcRect.w; x0 < x1; x0++)
        {
            xs++;
            xd++;

            //récupération du pixel source
            psrc = ((uint8_t *)m_pixels) + ys * m_pitch + xs * 3;
            pixel = *((uint32_t *)(psrc));

            //pixel destination
			pdst = ((uint8_t *)dstSurface.getPixels()) + yd * dstSurface.getPitch() + xd * 3;

            R8 = (pixel >> ECO_rshift) & 0xFF;
            G8 = (pixel >> ECO_gshift) & 0xFF;
            B8 = (pixel >> ECO_bshift) & 0xFF;
            *((pdst)+ECO_rshift/8) = R8;
            *((pdst)+ECO_gshift/8) = G8;
            *((pdst)+ECO_bshift/8) = B8;

            *pdst = pixel;
        }
    }

}

void OSurface::_blit_RGB_RGBA(ORect_i& srcRect, OSurface& dstSurface, ORect_i& dstRect)
{
    int xs,ys,xd,yd;
    uint8_t *psrc;
    uint32_t *pdst;
    uint32_t pixel;
    uint8_t R8=0,G8=0,B8=0,A8 = 255;

    //(-1 pour compenser xs++ yd++ ...)
    ys = srcRect.y -1;
    yd = dstRect.y -1;

    for (int y0 = 0, y1 = srcRect.h; y0 < y1; y0++)
    {
        ys++;
        yd++;

        xs = srcRect.x -1;
        xd = dstRect.x -1;

        for (int x0 = 0, x1 = srcRect.w; x0 < x1; x0++)
        {
            xs++;
            xd++;

            //récupération du pixel source
            psrc = ((uint8_t *)m_pixels) + ys * m_pitch + xs * 3;
            pixel = *((uint32_t *)(psrc));

            //convertion (A8=255) bgra rgba
            getRGBA(pixel, &R8, &G8, &B8, &A8);
            pixel = dstSurface.mapRGBA(R8, G8, B8, A8);

            //pixel destination
			pdst = (uint32_t*)dstSurface.getPixels() + xd + yd * dstSurface.getWidth();
            *pdst = pixel;
        }
    }

}

//non testé (en openGL on est en rgba)
void OSurface::_blit_RGBA_RGB(ORect_i& srcRect, OSurface& dstSurface, ORect_i& dstRect)
{
    int xs,ys,xd,yd;
    uint8_t R8,G8,B8;

    uint8_t *pdst;
    uint32_t pixel = 0;

    //(-1 pour compenser xs++ yd++ ...)
    ys = srcRect.y -1;
    yd = dstRect.y -1;

    for (int y0 = 0, y1 = srcRect.h; y0 < y1; y0++)
    {
        ys++;
        yd++;

        xs = srcRect.x -1;
        xd = dstRect.x -1;

        for (int x0 = 0, x1 = srcRect.w; x0 < x1; x0++)
        {
            xs++;
            xd++;

            //récupération du pixel source
			pixel = *(((uint32_t*)m_pixels) + xs + (ys * m_width));

            //pixel destination
            pdst = ((uint8_t *)dstSurface.getPixels()) + yd * dstSurface.getPitch() + xd * 3;

            //convertion RVB<->BGR ***
            R8 = (pixel >> ECO_rshift) & 0xFF;
            G8 = (pixel >> ECO_gshift) & 0xFF;
            B8 = (pixel >> ECO_bshift) & 0xFF;
            *((pdst)+ECO_rshift/8) = R8;
            *((pdst)+ECO_gshift/8) = G8;
            *((pdst)+ECO_bshift/8) = B8;

            *pdst = pixel;
        }
    }
    //ECO_error_set("ici rgba rgb");
}

void OSurface::_blit_RGBA_RGBA(ORect_i& srcRect, OSurface& dstSurface, ORect_i& dstRect)
{
    int xs,ys,xd,yd;
    uint8_t R8=0,G8=0,B8=0,A8=0;
    uint32_t R32, G32, B32, A32;

    uint32_t rmask,gmask,bmask,amask;
    uint32_t rshift,gshift,bshift,ashift;
    uint32_t pixel = 0;
    uint32_t *pdst;

	rmask = ECO_rmask;
	gmask = ECO_gmask;
	bmask = ECO_bmask;
	amask = ECO_amask;

	rshift = ECO_rshift;
	gshift = ECO_gshift;
	bshift = ECO_bshift;
	ashift = ECO_ashift;

    //(-1 pour compenser xs++ yd++ ...)
    ys = srcRect.y -1;
    yd = dstRect.y -1;

    for (int y0 = 0, y1 = srcRect.h; y0 < y1; y0++)
    {
        ys++;
        yd++;

        xs = srcRect.x -1;
        xd = dstRect.x -1;

        for (int x0 = 0, x1 = srcRect.w; x0 < x1; x0++)
        {
            xs++;
            xd++;

            //récupération du pixel source
            pixel = *(((uint32_t*)m_pixels) + xs + (ys * m_width));

            //convertion bgra rgba
            getRGBA(pixel, &R8, &G8, &B8, &A8);
			pixel = dstSurface.mapRGBA(R8, G8, B8, A8);

			pdst = (uint32_t*)dstSurface.getPixels() + xd + yd * dstSurface.getWidth();

            //blit
            if (A8 == 255)
            {
                *pdst = pixel;
            }
            else
            {
                uint32_t colp = *pdst;
                uint32_t dR, dG, dB;
                uint32_t surfaceAlpha, preMultR, preMultG, preMultB;
                uint32_t aTmp;

                dR = (pixel & rmask);
                dG = (pixel & gmask);
                dB = (pixel & bmask);
                //dA = (pixel & amask);

                preMultR = (A8 * (dR >> rshift));
                preMultG = (A8 * (dG >> gshift));
                preMultB = (A8 * (dB >> bshift));

                surfaceAlpha = ((colp & amask) >> ashift);
                aTmp = (255 - A8);

                A32 = 255 - ((aTmp * (255 - surfaceAlpha)) >> 8 );
                if (A32)
                {
                    aTmp *= surfaceAlpha;
                    R32 = (preMultR + ((aTmp * ((colp & rmask) >> rshift)) >> 8)) / A32 << rshift & rmask;
                    G32 = (preMultG + ((aTmp * ((colp & gmask) >> gshift)) >> 8)) / A32 << gshift & gmask;
                    B32 = (preMultB + ((aTmp * ((colp & bmask) >> bshift)) >> 8)) / A32 << bshift & bmask;

                    *pdst = R32 | G32 | B32 | (A32 << ashift & amask);
                }
            }
        //end for
        }
    }
}

/*
rectangle plein avec controle / blending
*/
void OSurface::boxFillS(ORect_i& dstRect, uint32_t color)
{
    int tmp, x1, y1, x2, y2;

    if (!dstRect.isValid())
    {
        x1 = 0;
        y1 = 0;
        x2 = m_width-1;
        y2 = m_height-1;
    }
    else
    {
        x1 = dstRect.x;
        y1 = dstRect.y;
        x2 = x1 + dstRect.w;
        y2 = y1 + dstRect.h;

        if (x2 < x1)
        {
            tmp = x1;
            x1 = x2;
            x2 = tmp;
        }
        if (y2 < y1)
        {
            tmp = y1;
            y1 = y2;
            y2 = tmp;
        }
        if (x2 >= m_width)
            x2 = m_width-1;
        if (y2 >= m_height)
            y2 = m_height-1;
    }

    for (int i = y1; i < y2; i++)
        horzLine(x1, i, x2, color);
}

/*
bordure de rectangle sécurisée, blending
*/
void OSurface::boxFrameS(ORect_i& dstRect, uint32_t color)
{
    int tmp, x1, y1, x2, y2;

    if (!dstRect.isValid())
    {
        x1 = 0;
        y1 = 0;
        x2 = m_width-1;
        y2 = m_height-1;
    }
    else
    {
        x1 = dstRect.x;
        y1 = dstRect.y;
        x2 = x1 + dstRect.w;
        y2 = y1 + dstRect.h;

        if (x2 < x1)
        {
            tmp = x1;
            x1 = x2;
            x2 = tmp;
        }
        if (y2 < y1)
        {
            tmp = y1;
            y1 = y2;
            y2 = tmp;
        }
        if (x2 >= m_width)
            x2 = m_width-1;
        if (y2 >= m_height)
            y2 = m_height-1;
    }

    horzLine(x1, y1, x2, color);
    horzLine(x1, y2, x2, color);
    vertLine(x1, y1, y2, color);
    vertLine(x2, y1, y2, color);
}

/*
retourne la composante R/G/B/A de la couleur passée en argument, d'après le format de la surface
*/
void OSurface::getRGBA(uint32_t color, uint8_t *R, uint8_t *G, uint8_t *B, uint8_t *A)
{
//#if (MODE_BYTEORDER == MODE_BIG_ENDIAN)
        // *** incertain
        /*
        if (m_bpp == 3)
        {
            *R = color >> 16;
            *G = color >> 8;
            *B = color >> 0;
        }
        else
        {
            *R = color >> 24;
            *G = color >> 16;
            *B = color >> 8;
            *A = color >> 0;
        }
    //#else
    */
        if (m_format == GL_BGRA || m_format == GL_BGR)
        {
            *A = color >> 24;
            *R = color >> 16;
            *G = color >> 8;
            *B = color >> 0;
        }
        else
        {
            *A = color >> 24;
            *B = color >> 16;
            *G = color >> 8;
            *R = color >> 0;
        }
    //#endif

    if (m_bpp == 3)
        *A = 0;
}

/*
calcule le nombre de bytes dans une ligne (+remplissage / padding) (pour passage de 3bytes en 4bytes de remplissage)
paramètres par defaut : -1 -1
*/
int OSurface::_calculatePitch(int testBpp, int testWidth)
{
	//See if we should use the class' own variables
	if (testWidth == -1)
		testWidth = m_width;

	if (testBpp == -1)
		testBpp = m_bpp;

	//Calculate the number of bits per line
	int bitsPerLine = testWidth * testBpp*8;

	//Find how many to add on to make 32-bit aligned
	int bitsToAdd = 0;

	if ((bitsPerLine%32)!= 0)
		bitsToAdd = 32 - (bitsPerLine%32);

	return (bitsPerLine+bitsToAdd)/8;
}

/*
effacement de la mémoire
*/
void OSurface::clear()
{
    if (m_pixels)
    {
        delete[] m_pixels;
    }

	m_pixels = NULL;
	m_width = 0;
    m_height = 0;
    m_bpp = 0;
    m_pitch = 0;
    m_format = 0; // format openGL RGB ou RGBA / BGR BGRA
}

/*
(création) copie de la surface pour former une nouvelle OSurface
*/
void OSurface::copy(int width, int height, int byteperpixel, void* pixels)
{
    if (width < 1) return;
    if (height < 1) return;
    if (byteperpixel < 3) return;

    clear();

    m_width = width;
    m_height = height;
    m_bpp = byteperpixel;
    m_pitch = width * byteperpixel;
    //format depuis Surface BGR sous window /RGB sous mac
	if (byteperpixel == 3)
	{
		//if (MODE_BYTEORDER == MODE_LIL_ENDIAN)
			m_format = GL_BGR;
		//else
		//	m_format = GL_RGB;
	}
	else
	{
		//if (MODE_BYTEORDER == MODE_LIL_ENDIAN)
			m_format = GL_BGRA;
		//else
		//	m_format = GL_RGBA;
	}

    m_pixels = new uint8_t[m_pitch * m_height];
	memcpy(m_pixels, pixels, m_pitch * m_height);
}

bool OSurface::exist() const
{
	return m_pixels != NULL;
}

/*
efface la surface avec la couleur passée en ref (0/clClear32 = transparence)
! la couleur dépend du mode interne RGB ou BGR
*/
void OSurface::fill(uint32_t color)
{
    if (m_pixels == NULL) return;

    //_LockSurface(dstSurface);
    int l = m_width-1;
    for (int i = 0; i < m_height; i++)
        horzLine(0, i, l, color);

    //_UnlockSurface(dstSurface);
}

/*
retournement vertical de l'image
*/
void OSurface::flipV()
{
	if (m_pixels == NULL) return;

	int h = m_height / 2;
	uint8_t *top = m_pixels;
	uint8_t *bottom = m_pixels + (m_pitch * (m_height-1));
	uint8_t *tmp = new uint8_t[m_pitch];

	for (int n = 0; n < h; n++)
	{
		//_swap(bottom, top, m_pitch);
		memcpy(tmp, bottom, m_pitch);
		memcpy(bottom, top, m_pitch);
		memcpy(top, tmp, m_pitch);

		top += m_pitch;
		bottom -= m_pitch;
	}

	delete [] tmp;
}

/*
retourne la couleur du pixel en x/y
*/
uint32_t OSurface::getPixel(int x, int y) const
{
	if (x < 0 || y < 0 || x >= m_width || y >= m_height) return 0;

	uint32_t color;

    //_LockSurface(srcSurface);

    uint8_t *p = (uint8_t *)m_pixels + y * m_pitch + x * m_bpp;

    switch(m_bpp)
    {
    case 3:
        //if (MODE_BYTEORDER == MODE_BIG_ENDIAN)
        //    color = p[0] << 16 | p[1] << 8 | p[2];
        //else
            color = p[0] | p[1] << 8 | p[2] << 16;
        break;
    case 4:
        color = *(uint32_t*)p;
        break;
    default:
        color = 0;
        break;
    }

    //_UnlockSurface(srcSurface);

    return color;
}


void OSurface::getPixel_RGBA(int x, int y, uint8_t *R, uint8_t *G, uint8_t *B, uint8_t *A)
{
    if (x < 0 || y < 0 || x >= m_width || y >= m_height) return;

    //_LockSurface(srcSurface);

    uint8_t *p = (uint8_t *)m_pixels + y * m_pitch + x * m_bpp;
/*
    // surface rgba
    if (m_bpp == 3)
    {
        *A = 0;
        *R = p[0];
        *G = p[1];
        *B = p[2];
    }
    else
    {
        *R = p[0];
        *G = p[1];
        *B = p[2];
        *A = p[3];
    }
*/
    if (m_format == GL_BGRA || m_format == GL_BGR)
    {
        *A = p[3];
        *R = p[2];
        *G = p[1];
        *B = p[0];
    }
    else
    {
        *A = p[3];
        *B = p[2];
        *G = p[1];
        *R = p[0];
    }
    //#endif

    if (m_bpp == 3) *A = 0;
}


/*
trace une ligne horizontale non sécurisée, blending
*/
void OSurface::horzLine(int x1, int y, int x2, uint32_t color)
{
    // *** _LockSurface(dstSurface);

    if (m_bpp == 3)
    {
        for (int i = x1; i <= x2; i++)
            _setPixelRGB(i, y, color);
    }
    else
    {
        for (int i = x1; i <= x2; i++)
            _setPixelRGBA(i, y, color);
    }

    // *** _UnlockSurface(dstSurface);
}

/*
trace une ligne horizontale sécurisée, blending
*/
void OSurface::horzLineS(int x1, int y, int x2, uint32_t color)
{
    int tmp;
	int w = m_width;
	int h = m_height;

    if (y < 0) return;
    if (y >= h) return;

    if (x2 < x1)
    {
        tmp = x1;
        x1 = x2;
        x2 = tmp;
    }

    if (x1 < 0) x1 = 0;
    if (x1 > w -1) x1 = w -1;

    if (x2 < 0) x2 = 0;
    if (x2 > w -1) x2 = w -1;

    // *** _LockSurface(dstSurface);

    if (m_bpp == 3)
    {

        for (int i = x1; i <= x2; i++)
            _setPixelRGB(i, y, color);
    }
    else
    {
        for (int i = x1; i <= x2; i++)
            _setPixelRGBA(i, y, color);
    }

    // *** _UnlockSurface(dstSurface);
}

/*
retourne la combinaison des valeurs en une couleur 4 octets
*/
uint32_t OSurface::mapRGBA(uint8_t R, uint8_t G, uint8_t B, uint8_t A)
{
/*
    if (m_format == GL_RGBA || m_format == GL_RGB)
        return (R << 24 | G << 16 | B << 8 | A);
    else
		return (A << 24 | R << 16 | G << 8 | B);
*/
    //#if (MODE_BYTEORDER == MODE_BIG_ENDIAN)
    //    return (R << 24 | G << 16 | B << 8 | A);      //mode big endian
    //#else
        if (m_format == GL_RGBA || m_format == GL_RGB)
            return (A << 24 | B << 16 | G << 8 | R);  //mode openGl
        else
            return (A << 24 | R << 16 | G << 8 | B);  //mode classique
    //#endif

}

/*
change le taille de l'image
*/
void OSurface::resize(int width, int height, bool antiAliased)
{
    struct Srgba
    {
        uint8_t r;
        uint8_t g;
        uint8_t b;
        uint8_t a;
    };
	int sx, sy, *sax, *say, *csax, *csay, csx, csy, ex, ey, t1, t2, sstep, lx, ly;
	Srgba *c00, *c01, *c10, *c11;
	Srgba *sp, *csp, *dp;
	int dgap;
	OSurface tmp;

    if (m_bpp < 4)
    {
        ECO_error_set("uniquement des images 32bits >OSurface.resize");
        return;
    }
    if (width < 4 || height < 4) return;

	tmp.create(width, height, 4, GL_BGRA);

	if (antiAliased)
	{
		// For interpolation: assume source dimension is one pixel
		//smaller to avoid overflow on right and bottom edge.
		sx = (int) (65536.0 * (double)(m_width - 1) / (double)width);
		sy = (int) (65536.0 * (double)(m_height - 1) / (double)height);
	}
	else
	{
		sx = (int) (65536.0 * (double)m_width / (double)width);
		sy = (int) (65536.0 * (double)m_height / (double)height);
	}

	// Allocate memory for row increments
	if ((sax = (int *) malloc((width + 1) * sizeof(uint32_t))) == NULL)
	{
		return;
	}
	if ((say = (int *) malloc((height + 1) * sizeof(uint32_t))) == NULL)
	{
		free(sax);
		return;
	}

	// Precalculate row increments
	sp = csp = (Srgba*)m_pixels;
	dp = (Srgba*)tmp.m_pixels;

	csx = 0;
	csax = sax;
	for (int x = 0; x <= width; x++)
	{
		*csax = csx;
		csax++;
		csx &= 0xffff;
		csx += sx;
	}
	csy = 0;
	csay = say;
	for (int y = 0; y <= height; y++)
	{
		*csay = csy;
		csay++;
		csy &= 0xffff;
		csy += sy;
	}

	dgap = tmp.m_pitch - width * 4;
	//dgap = m_width - width * 4;

	// Switch between interpolating and non-interpolating code
	if (antiAliased)
	{
		// Interpolating Zoom / Scan destination
		csay = say;
		ly = 0;
		for (int y = 0; y < height; y++)
		{
			// Setup color source pointers
			c00 = csp;
			c01 = csp;
			c01++;
			c10 = csp;
			c10 += m_pitch/4;
			c11 = c10;
			c11++;

			csax = sax;
			lx = 0;
			for (int x = 0; x < width; x++)
			{
				// Draw and interpolate colors
				ex = (*csax & 0xffff);
				ey = (*csay & 0xffff);
				t1 = ((((c01->r - c00->r) * ex) >> 16) + c00->r) & 0xff;
				t2 = ((((c11->r - c10->r) * ex) >> 16) + c10->r) & 0xff;
				dp->r = (((t2 - t1) * ey) >> 16) + t1;
				t1 = ((((c01->g - c00->g) * ex) >> 16) + c00->g) & 0xff;
				t2 = ((((c11->g - c10->g) * ex) >> 16) + c10->g) & 0xff;
				dp->g = (((t2 - t1) * ey) >> 16) + t1;
				t1 = ((((c01->b - c00->b) * ex) >> 16) + c00->b) & 0xff;
				t2 = ((((c11->b - c10->b) * ex) >> 16) + c10->b) & 0xff;
				dp->b = (((t2 - t1) * ey) >> 16) + t1;
				t1 = ((((c01->a - c00->a) * ex) >> 16) + c00->a) & 0xff;
				t2 = ((((c11->a - c10->a) * ex) >> 16) + c10->a) & 0xff;
				dp->a = (((t2 - t1) * ey) >> 16) + t1;

				// Advance source pointers
				csax++;
				if (*csax > 0)
				{
					sstep = (*csax >> 16);
					lx += sstep;
					if (lx <= m_width)
					{
						c00 += sstep;
						c01 += sstep;
						c10 += sstep;
						c11 += sstep;
					}
				}

				// Advance destination pointer
				dp++;
			}

			// Advance source pointer
			csay++;
			if (*csay > 0)
			{
				sstep = (*csay >> 16);
				ly += sstep;
				if (ly < m_height)
				{
					csp += (sstep * (m_pitch / 4));
				}
			}

			// Advance destination pointers
			dp = (Srgba*) ((uint8_t*) dp + dgap);
		}
	}
	else
	{
		// Non-Interpolating Zoom
		csay = say;
		for (int y = 0; y < height; y++)
		{
			sp = csp;
			csax = sax;
			for (int x = 0; x < width; x++)
			{
				// Draw
				*dp = *sp;
				// Advance source pointers
				csax++;
				if (*csax > 0)
				{
					sstep = (*csax >> 16);
					sp += sstep;
				}
				// Advance destination pointer
				dp++;
			}
			// Advance source pointer
			csay++;
			if (*csay > 0)
			{
				sstep = (*csay >> 16) * (m_pitch/4);
				csp += sstep;
			}

			// Advance destination pointers
			dp = (Srgba*) ((uint8_t*) dp + dgap);
		}
	}

	free(sax);
	free(say);

	create(width, height, 4, GL_BGRA);
	for (int i = 0, size = m_pitch * height; i < size; i++)
		m_pixels[i] = tmp.m_pixels[i];
}

/*
sauvegarde
*/
uint32_t OSurface::save(std::string file)
{
    uint32_t error;

	if (m_pixels == NULL) return false;
	if (m_bpp < 3) //n'arrivera jamais
	{
		ECO_error_set("Sauvegarde depuis format 24/32 bits uniquement >OSurface.save");
		return false;
	}

	std::string path,name;
	path = ECO_fileGetPath(file);
    name = ECO_fileGetName(file,false);
    //ECO_error_set("1> %s", name.c_str());

    //name = path + name + ".bmp";
    name = path + name + ".png";
    // si le fichier n'est pas supprimé ainsi, il y a des erreurs
    if (ECO_fileExist(name))
    {
        ECO_fileRemove(name);
    }
    //flipV();
    //error = loaderBMP_save(name, m_format, m_width, m_height, m_pixels);
    //flipV();

    // bug sauvegarde en mode indexé =
    // corriger lodePng.cpp / ligne 3257 = changer pour rgba par defaut

    /*
    void lodepng_color_stats_init(LodePNGColorStats* stats) {
        stats->colored = 0;
        stats->key = 0;
        stats->key_r = stats->key_g = stats->key_b = 0;
        stats->alpha = 1; //0
        stats->numcolors = 0;
        stats->bits = 4;  //1
        stats->numpixels = 0;
        stats->allow_palette = 0; //1
        stats->allow_greyscale = 0 //1;
    }
    */
    uint32_t w = m_width, h = m_height;
    error = lodepng_encode32_file(name.c_str(), m_pixels, w, h);

    //error = lodepng_encode_file(name.c_str(), m_pixels, w, h, LCT_RGBA, 8);

    if(error)
    {
        ECO_error_set("error %u: %s >OSurface.save", error, lodepng_error_text(error));
    }
    return error;
}

//version non sécurisé, l'affichage hors zone provoque des erreurs
void OSurface::setPixel(int x, int y, uint32_t color)
{
	if (m_bpp == 3)
		_setPixelRGB(x,y,color);
	else
		_setPixelRGBA(x,y,color);
}

//version sécurisé, ne dépasse pas de la zone
void OSurface::setPixelS(int x, int y, uint32_t color)
{
	if (x < 0 || y < 0 || x >= m_width || y >= m_height) return;

	if (m_bpp == 3)
		_setPixelRGB(x,y,color);
	else
		_setPixelRGBA(x,y,color);
}

/*
place un pixel aux coordonnées x,y de couleur color RVB
version non sécurisée (peu planter si pixel hors zone image)
>> bloquer la surface en cas d'accès direct !!
non testé
*/
void OSurface::_setPixelRGB(int x, int y, uint32_t color)
{
	uint8_t R8,G8,B8;

    uint8_t *pixel = ((uint8_t *)m_pixels) + y * m_pitch + x * 3;

	R8 = (color >> ECO_rshift) & 0xFF;
    G8 = (color >> ECO_gshift) & 0xFF;
    B8 = (color >> ECO_bshift) & 0xFF;
    *((pixel) + ECO_rshift/8) = R8;
    *((pixel) + ECO_gshift/8) = G8;
    *((pixel) + ECO_bshift/8) = B8;
}

/*
place un pixel aux coordonnées x,y de couleur color RVB-RVBA (blending supporté)
version non sécurisée (peu planter si pixel hors zone image)
>> bloquer la surface en cas d'accès direct !!
*/
void OSurface::_setPixelRGBA(int x, int y, uint32_t color)
{
    uint32_t R32 = 0, G32 = 0, B32 = 0, A32 = 0;
	uint8_t A8;

    uint32_t rmask = ECO_rmask;
    uint32_t gmask = ECO_gmask;
    uint32_t bmask = ECO_bmask;
    uint32_t amask = ECO_amask;

    uint32_t rshift = ECO_rshift;
    uint32_t gshift = ECO_gshift;
    uint32_t bshift = ECO_bshift;
    uint32_t ashift = ECO_ashift;

    A8 = (color & amask) >> ashift;

    if (A8 == 255)
        // *((uint32_t*)m_pixels + x + y * m_width) = color;
        *((uint32_t*)m_pixels + ((y * m_width)+x)) = color;
    else
    {
        uint32_t *p = (uint32_t*)m_pixels + x + y * m_width;
        uint32_t colp = *p;
        uint32_t dR, dG, dB;
        uint32_t surfaceAlpha, preMultR, preMultG, preMultB;
        uint32_t aTmp;

        dR = (color & rmask);
        dG = (color & gmask);
        dB = (color & bmask);
        //dA = (color & amask);

        preMultR = (A8 * (dR >> rshift));
        preMultG = (A8 * (dG >> gshift));
        preMultB = (A8 * (dB >> bshift));

        surfaceAlpha = ((colp & amask) >> ashift);
        aTmp = (255 - A8);

        A32 = 255 - ((aTmp * (255 - surfaceAlpha)) >> 8 );
        if (A32)
        {
            aTmp *= surfaceAlpha;
            R32 = (preMultR + ((aTmp * ((colp & rmask) >> rshift)) >> 8)) / A32 << rshift & rmask;
            G32 = (preMultG + ((aTmp * ((colp & gmask) >> gshift)) >> 8)) / A32 << gshift & gmask;
            B32 = (preMultB + ((aTmp * ((colp & bmask) >> bshift)) >> 8)) / A32 << bshift & bmask;
            //*p = R32 | G32 | B32 | (A32 << ashift & amask);
            *p = R32 | G32 | B32 | (A32 << ashift & amask);
        }
    }
}

void OSurface::setAlpha(uint8_t alpha)
{
	if (m_bpp < 4 || m_pixels == NULL)
        return;

    // *** _LockSurface(dstSurface);

    uint8_t *pdst = (uint8_t *)m_pixels;

    //if (MODE_BYTEORDER == MODE_LIL_ENDIAN)
        pdst += 3;

	for (int i = 0, size = m_width * m_height -1; i < size; i++)
    {
        *pdst = alpha;
        pdst += 4;
    }

    // *** _UnlockSurface(dstSurface);
}

void OSurface::_swap(void *byte1, void *byte2, int size)
{
    uint8_t *tmp = new uint8_t[size];

    memcpy(tmp, byte1, size);
    memcpy(byte1, byte2, size);
    memcpy(byte2, tmp, size);

    delete [] tmp;
}

/*
trace une ligne vertcale non sécurisée, blending
*/
void OSurface::vertLine(int x, int y1, int y2, uint32_t color)
{
    // *** _LockSurface(dstSurface);

    if (m_bpp == 3)
    {
        for (int i = y1; i <= y2; i++)
            _setPixelRGB(x, i, color);
    }
    else
    {
        for (int i = y1; i <= y2; i++)
            _setPixelRGBA(x, i, color);
    }

    // *** _UnlockSurface(dstSurface);
}

/*
trace une ligne verticale sécurisée, blending
*/
void OSurface::vertLineS(int x, int y1, int y2, uint32_t color)
{
    int tmp;
    int w = m_width;
    int h = m_height;

    if (x < 0) return;
    if (x >= w) return;

    if (y2 < y1)
    {
        tmp = y1;
        y1 = y2;
        y2 = tmp;
    }

    if (y1 < 0) y1 = 0;
    if (y1 > h -1) y1 = h -1;

    if (y2 < 0) y2 = 0;
    if (y2 > h -1) y2 = h -1;

    // *** _LockSurface(dstSurface);

    if (m_bpp == 3)
    {
        for (int i = y1; i <= y2; i++)
            _setPixelRGB(x, i, color);
    }
    else
    {
        for (int i = y1; i <= y2; i++)
            _setPixelRGBA(x, i, color);
    }

    // *** _UnlockSurface(dstSurface);
}



