#ifndef OCAMERA_H_INCLUDED
#define OCAMERA_H_INCLUDED

/*
OBJET       classe d'une camera simple

DATE        12/2019

AUTEUR      philippe Thebaud

COMMENTAIRE z est la verticale
*/

#include <GL/glew.h>
//#include <cmath>

#include "OUtils.h"
#include "OKeyboard.h"


class OCamera
{
public:
    OCamera();
    ~OCamera();

    void        anim();

    void        create(float x, float y, float z, float angleH, float angleV);
    void        create(OVec3_f& pos, OVec3_f& rot);

    float		getAngleH();
    float       getAngleV();
    float       getIncline();
    OVec3_f&    getPos();
    float       getPosX();
    float       getPosY();
    float       getPosZ();
    OVec3_f&    getRegard();
    OVec3_f&    getRot();

    void        incAngleH(float value);
    void        incAngleV(float value);
    void        incIncline(float value);
    void        incPosX(float value);
    void        incPosY(float value);
    void        incPosZ(float value);

    void        keyboard(OKeyboard& keyboard);

    void        lookAt(OMat4& view);

    //void        move(OKeyboard& keyboard);
    void        move_front(bool free = false);
    void        move_back(bool free = false);
    void        move_left();
    void        move_right();
    void        move_up(float acceleration = 1.0);
    void        move_down();
    void        move_side_left();
    void        move_side_right();
    void        move_head_down();
    void        move_head_up();
    void        move_head_left();
    void        move_head_right();
    void        move_raz();

    void        setAngleH(float angleH);
    void        setAngleV(float angleV);
    void        setCoefRot(float value);
    void        setIncline(float value);
    void        setPos(OVec3_f& pos);
    void        setPos(float x, float y, float z);
    void        setRot(OVec3_f& rot);
    void        setRot(float x, float y, float z);
    void        setRoute(OVec3_f poigne[4], float vitesse, OVec3_f& cible);
    void        setSpeed(float value);
    void        setSpeedRot(float value);
    void        setTarget(OVec3_f pos, float angleH, float hauteur, float distance);

private:

    OVec3_f     _bezier(OVec3_f poigne[4], float interval);

    float       _rotation(float cap_actuel, float cap_demande);

    void        _vectorFromAngle();

private:

    OVec3_f     m_pos,m_rot,m_regard,m_cote;
    OVec3_f     m_cible;
    float       m_speed, m_coefRot;

    //
	struct Sbezier
	{
	    float px, py, pz, rx, ry, rz;

	    Sbezier(float px_, float py_, float pz_, float rx_, float ry_, float rz_)
        {
	        px = px_; py = py_; pz = pz_;
	        rx = rx_; ry = ry_; rz = rz_;
	    }
	    void set(float px_, float py_, float pz_, float rx_, float ry_, float rz_)
	    {
	        px = px_; py = py_; pz = pz_;
	        rx = rx_; ry = ry_; rz = rz_;
	    }
	};
	std::vector<Sbezier> m_route;
	size_t      m_route_index;
	//float       m_route_vitesse;
};

#endif
