#include "OTextureList.h"

static std::string  p_path = "donnees/interface/";
static bool         p_mipmap = false;
static int          p_filter = OTEXTURELIST_MESH;

// -----------------------
// --- le constructeur ---
// -----------------------

OTextureList::OTextureList()
{
    clear();
}

// ----------------------
// --- le destructeur ---
// ----------------------

OTextureList::~OTextureList()
{
    clear();
}

// --------------------
// --- les méthodes ---
// --------------------


/*
ajout d'une texture selon la référence fichier
attention on ne prend que le nom du fichier pour la clef, pas le répertoire,
il faut donc donner des noms différents à des fichiers placés dans des répertoires différents:
rep1/fond.png == rep2/fond.png !!!
*/
void OTextureList::add(std::string refTexture)
{
    OSurface surface;

    //compteur nombre de texture reference identique
	m_compteur[refTexture]++;
    //controle texture non chargée
    for (typeTexture::iterator it = m_texture.begin(); it != m_texture.end(); it++)
    {
        if (it->first == refTexture)
            return; // it->second;
    }
	//si erreur on decremente le compteur
	if (!_load(refTexture, surface))
	{
		ECO_error_set("erreur %s >OTextureList.add2", refTexture.c_str());
		m_compteur[refTexture]--;
		return;
	}
	_make(refTexture, surface);
}

/*
ajout d'une texture de couleur / obj sans texture
le fichier obj doit avoir eté fait avec le mode illum 0
*/
void OTextureList::add(std::string refTexture, float r, float g, float b, float a)
{
    OSurface surface;
    uint32_t color;
    uint8_t alpha = ECO_min(255, a * 255);
    uint8_t red = ECO_min(255, r * 255);
    uint8_t green = ECO_min(255, g * 255);
    uint8_t blue = ECO_min(255, b * 255);

	//compteur nombre de texture reference identique
	m_compteur[refTexture]++;
    //controle texture non chargée
    for (typeTexture::iterator it = m_texture.begin(); it != m_texture.end(); it++)
    {
        if (it->first == refTexture)
            return; // it->second;
    }

    //noter passage abgr -> argb
    color  = alpha << 24 | blue << 16 | green << 8 | red << 0;
    surface.create(32, 32, ECO_BPP4_32, GL_RGBA);
    surface.fill(color);

	_make(refTexture, surface);
}

/*
efface les textures chargées
*/
void OTextureList::clear()
{
    for (typeTexture::iterator it = m_texture.begin(); it != m_texture.end(); it++)
    {
        if(glIsTexture(it->second) == GL_TRUE)
        {
			glDeleteTextures(1, &it->second);
        }
    }
	m_texture.clear();
    m_height.clear();
    m_width.clear();
    m_compteur.clear();
}

/*
suppression d'une texture
*/
bool OTextureList::del(std::string refTexture)
{
    //si la texture existe
    if (m_compteur[refTexture])
        m_compteur[refTexture]--;
    else
        return false;
    //si la texture n'est plus utilisée
    if (m_compteur[refTexture] == 0)
    {
        //liberation de la texture
        glDeleteTextures(1, &m_texture[refTexture]);
        //suppression de la référence de la texture
        m_texture.erase(refTexture);
        m_width.erase(refTexture);
        m_height.erase(refTexture);
        m_compteur.erase(refTexture);
    }
    return true;
}

bool OTextureList::del(uint32_t refTextureID)
{
	std::string refTexture = "";

	for (typeTexture::iterator it = m_texture.begin(); it != m_texture.end(); it++)
        if(glIsTexture(it->second) == refTextureID)
			refTexture = it->first;
	if (refTexture == "" ) return false;
	//si la texture existe
    if (m_compteur[refTexture])
        m_compteur[refTexture]--;
    else
        return false;
    //si la texture n'est plus utilisée
    if (m_compteur[refTexture] == 0)
    {
        //liberation de la texture
        glDeleteTextures(1, &refTextureID);
        //suppression de la référence de la texture
        m_texture.erase(refTexture);
        m_width.erase(refTexture);
        m_height.erase(refTexture);
        m_compteur.erase(refTexture);
    }

    return true;
}

uint32_t OTextureList::getHeight(std::string refTexture)
{
    for (typeTexture::iterator it = m_height.begin(); it != m_height.end(); it++)
    {
        if (it->first == refTexture)
            return it->second;
    }
    return 0;
}

uint32_t OTextureList::getWidth(std::string refTexture)
{
    for (typeTexture::iterator it = m_width.begin(); it != m_width.end(); it++)
    {
        if (it->first == refTexture)
            return it->second;
    }
    return 0;
}

/*
la référence null permet de faire une boucle sans msg d'erreur
pour une texture inexistante mais référencée
*/
uint32_t OTextureList::getID(std::string refTexture)
{
    if (refTexture == "null")
        return 0;
    for (typeTexture::iterator it = m_texture.begin(); it != m_texture.end(); it++)
    {
        if (it->first == refTexture)
            return it->second;
    }
    return 0;
}

s_texParam OTextureList::getParam(std::string refTexture)
{
    s_texParam tmp;
	tmp.id = 0; tmp.w =1.0; tmp.h = 1.0;

    if (refTexture == "null")
        return tmp;
    for (typeTexture::iterator it = m_texture.begin(); it != m_texture.end(); it++)
    {
        if (it->first == refTexture)
             tmp.id = it->second;
    }
    if (tmp.id == 0)
        ECO_error_set("erreur référence de texture : %s >OTextureList.getParam", refTexture.c_str());

    tmp.w = getWidth(refTexture);
    tmp.h = getHeight(refTexture);

    return tmp;
}

// si on dispose de l'index (on se sert de textureList comme d'une liste)
s_texParam OTextureList::getParam(uint32_t index)
{
    s_texParam tmp;
	tmp.id = 0; tmp.w = 1.0; tmp.h = 1.0;

	if (index >= m_texture.size())
    {
        ECO_error_set("erreur référence de texture >OTextureList.getParamIndex");
        return tmp;
    }

    uint32_t cpt = 0;
    for (typeTexture::iterator it = m_texture.begin(); it != m_texture.end(); it++)
    {
        if (index == cpt)
        {
            std::string refTexture = it->first;

            tmp.id = it->second;
            tmp.w = getWidth(refTexture);
            tmp.h = getHeight(refTexture);
            break;
        }
        cpt++;
    }

    return tmp;
}

/*
retourne la clef correspondant à l'id
*/
std::string OTextureList::getReference(uint32_t refId)
{
    for (typeTexture::iterator it = m_texture.begin(); it != m_texture.end(); it++)
    {
        if (it->second == refId)
        {
            return it->first;
        }
    }
    return "";
}

/*
retourne le nombre de texture chargées
*/
uint32_t OTextureList::getSize()
{
	return m_texture.size();
}

/*
incremente le compteur / lorsque l'on fait une copie de mesh
*/
void OTextureList::incCounter(uint32_t refTextureID)
{
	std::string refTexture = "";

	for (typeTexture::iterator it = m_texture.begin(); it != m_texture.end(); it++)
        if(glIsTexture(it->second) == refTextureID)
			refTexture = it->first;
	if (refTexture == "" ) return;

	m_compteur[refTexture]++;
}

bool OTextureList::_load(std::string refMap, OSurface &surface)
{
	std::string chemin;

    chemin = p_path + refMap;
    surface.load(chemin);
    if (!surface.exist())
    {
        ECO_error_set("Erreur chargement image : %s >OTextureList.load", chemin.c_str());
        return false;
    }

    return true;
}

void OTextureList::_make(std::string refTexture, OSurface& surface)
{
    uint32_t textureID = 0;

    //activation des textures
    glEnable(GL_TEXTURE_2D);
    //generation de la texture
    glGenTextures(1, &textureID);
    //selection de la texture
    glBindTexture(GL_TEXTURE_2D, textureID);

    //chargement de la texture
	int w = surface.getWidth();
	int h = surface.getHeight();
	// génération
	glTexImage2D(GL_TEXTURE_2D, 0, surface.getBpp(), w, h, 0, surface.getFormat(), GL_UNSIGNED_BYTE, surface.getPixels() );

	// le mipmap s'utilise avec une texture carré, puissance de 2 128x128 256x256 ...
	// possible aussi 128x64, 256x512, ... mais ralenti
	// ici il permet aussi de convertir une image non puissance de 2 (à éviter)
	if (((w & (w-1)) != 0) || ((h & (h-1)) != 0) || p_mipmap)
	{
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
        //glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR );
        //glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR_MIPMAP_NEAREST );
	    //glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST_MIPMAP_LINEAR );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR );
        //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glGenerateMipmap(GL_TEXTURE_2D);

	}
	else
	{
        // texture interface
        switch(p_filter)
        {
        case OTEXTURELIST_INTERFACE:
            // texture proche = non lissée
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
            // texture lointaine ou scale
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
            break;
        case OTEXTURELIST_MESH:
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
            break;
        case OTEXTURELIST_EDGE:
            // texture proche = non lissée
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
            // texture lointaine ou scale
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
            // paramètre pour une image avec transparence
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
            break;
        case OTEXTURELIST_MIPMAP:
            //GL_NEAREST_MIPMAP_NEAREST : utilise la mipmap correspondant le mieux à la taille du pixel sur lequel la texture est appliquée et échantillonne en utilisant l'interpolation du plus proche voisin ;
            //GL_LINEAR_MIPMAP_NEAREST : échantillonne la mipmap la plus proche avec l'interpolation linéaire ;
            //GL_NEAREST_MIPMAP_LINEAR : utilise les deux mipmaps les plus proches de la taille du pixel sur lequel la texture est appliquée et effectue l'échantillonnage avec l'interpolation du plus proche voisin ;
            //GL_LINEAR_MIPMAP_LINEAR : échantillonne les deux mipmaps les plus proches avec l'interpolation linéaire.

            //glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY, 16.0);

            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST_MIPMAP_NEAREST);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST_MIPMAP_NEAREST);

            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

            // ? en gros : le mipmap n'est plus généré après x distance
            //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAX_LOD, 4);
            glGenerateMipmap(GL_TEXTURE_2D);
            break;

        case OTEXTURELIST_MIP_MANUAL:

            glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY, 8.0);

            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST_MIPMAP_NEAREST);
            //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR_MIPMAP_NEAREST);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST_MIPMAP_NEAREST);

            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAX_LEVEL, 5);
            glTexImage2D(GL_TEXTURE_2D, 0, surface.getBpp(), w, h, 0, surface.getFormat(), GL_UNSIGNED_BYTE, surface.getPixels() );
            glTexImage2D(GL_TEXTURE_2D, 1, surface.getBpp(), w, h, 0, surface.getFormat(), GL_UNSIGNED_BYTE, surface.getPixels() );
            glTexImage2D(GL_TEXTURE_2D, 2, surface.getBpp(), w/2, h/2, 0, surface.getFormat(), GL_UNSIGNED_BYTE, surface.getPixels() );
            glTexImage2D(GL_TEXTURE_2D, 3, surface.getBpp(), w/4, h/4, 0, surface.getFormat(), GL_UNSIGNED_BYTE, surface.getPixels() );
            glTexImage2D(GL_TEXTURE_2D, 4, surface.getBpp(), w/8, h/8, 0, surface.getFormat(), GL_UNSIGNED_BYTE, surface.getPixels() );
            //glTexImage2D(GL_TEXTURE_2D, 5, surface.getBpp(), w/16, h/16, 0, surface.getFormat(), GL_UNSIGNED_BYTE, surface.getPixels() );

            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
            //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
            //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
            glGenerateMipmap(GL_TEXTURE_2D);

            break;
        }
	}

    m_texture[refTexture] = textureID;
    m_width[refTexture] = w;
    m_height[refTexture] = h;

	//déverrouillage libération
    glBindTexture(GL_TEXTURE_2D, 0);
    //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAX_LEVEL, 1);
}

/*
ajoute un filtre
penser à passer setFilter(0,0,0) pour remettre à zéro/normal
*/
	//elimine les bordures
		//glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE );
		//glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE );
	//bordures noires
		//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
		//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
	//objet 2d
		//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		//glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP );
		//glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP );
	//objet 3d
		//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		//glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);


	// set up hardware shadow mapping
	// glTexParameteri(tex_target, GL_TEXTURE_COMPARE_SGIX, GL_TRUE);
	// glTexParameteri(tex_target, GL_TEXTURE_COMPARE_OPERATOR_SGIX, GL_TEXTURE_LEQUAL_R_SGIX);




// ----------------------
// --- les propriétés ---
// ----------------------

void OTextureList::P_setFilter(uint32_t mode)
{
    p_filter = mode;
}

void OTextureList::P_setPath(const std::string path)
{
    p_path = path;
    //ECO_error_set("texturelist path : %s", p_path.c_str());
}

void OTextureList::P_setMipmap(bool mode)
{
    p_mipmap = mode;
}

std::string OTextureList::P_getPath()
{
    return p_path;
}


/*
fonction (externe) chargement d'une texture
libérez la texture en fin !
*/
s_texParam ECO_loadTexture(std::string file, uint32_t filter, bool useMipMap)
{
	OSurface surface;
	s_texParam texParam;
	texParam.id = 0;

	surface.load(file);
	if (!surface.exist())
	{
		ECO_error_set("echec chargement %s >ECO_loadTexture", file.c_str());
		return texParam;
	}

    //activation des textures
    glEnable(GL_TEXTURE_2D);
    //if (texParam.id)
    //    glDeleteTextures(1,&texParam.id);
    //generation de la texture
    glGenTextures(1, &texParam.id);
    //selection de la texture
    glBindTexture(GL_TEXTURE_2D, texParam.id);
	// génération
	texParam.w = surface.getWidth();
	texParam.h = surface.getHeight();
	glTexImage2D(GL_TEXTURE_2D, 0, surface.getBpp(), texParam.w, texParam.h, 0, surface.getFormat(), GL_UNSIGNED_BYTE, surface.getPixels() );

	// on applique les filtres usuels
	if (((texParam.w & (texParam.w-1)) != 0) || ((texParam.h & (texParam.h-1)) != 0) || useMipMap)
	{
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR_MIPMAP_NEAREST );
        glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
        switch(filter)
        {
        case OTEXTURELIST_INTERFACE:
            // texture proche = non lissée
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
            // texture lointaine ou scale
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
            break;
        case OTEXTURELIST_MESH:
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
            break;
        case OTEXTURELIST_EDGE:
            // texture proche = non lissée
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
            // texture lointaine ou scale
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
            break;
        case OTEXTURELIST_MIPMAP:
            //glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR );
            //glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR_MIPMAP_NEAREST );

            //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
            //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

            glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
            glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
            glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
            glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST_MIPMAP_NEAREST);
            glGenerateMipmap(GL_TEXTURE_2D);
            break;
        }
	}

	//déverrouillage libération
    glBindTexture(GL_TEXTURE_2D, 0);

    return texParam;
}

/*
Filter Combination                     | Bilinear | Bilinear | Mipmapping
(MAG_FILTER / MIN_FILTER)              | (Near)   | (FAR)    |
---------------------------------------+----------+----------+------------
GL_NEAREST / GL_NEAREST_MIPMAP_NEAREST | Off      | Off      | Standard
GL_NEAREST / GL_LINEAR_MIPMAP_NEAREST  | Off      | On       | Standard
GL_NEAREST / GL_NEAREST_MIPMAP_LINEAR  | Off      | Off      | Trilinear filtering
GL_NEAREST / GL_LINEAR_MIPMAP_LINEAR   | Off      | On       | Trilinear filtering
GL_NEAREST / GL_NEAREST                | Off      | Off      | None
GL_NEAREST / GL_LINEAR                 | Off      | On       | None
GL_LINEAR / GL_NEAREST_MIPMAP_NEAREST  | On       | Off      | Standard
GL_LINEAR / GL_LINEAR_MIPMAP_NEAREST   | On       | On       | Standard
GL_LINEAR / GL_NEAREST_MIPMAP_LINEAR   | On       | Off      | Trilinear filtering
GL_LINEAR / GL_LINEAR_MIPMAP_LINEAR    | On       | On       | Trilinear filtering
GL_LINEAR / GL_NEAREST                 | On       | Off      | None
GL_LINEAR / GL_LINEAR                  | On       | On       | None
*/





