#ifndef OMAT4_H_INCLUDED
#define OMAT4_H_INCLUDED

/*
OBJET       classe d'une matrice 4x4

DATE        12/2019

AUTEUR      philippe Thebaud

COMMENTAIRE 0  1  2  3  utilisez transpose true dans les appels ex glGetUniformLocation
            4  5  6  7
            8  9 10 11
            12 13 14 15

            near et far sont définie par windows ! d'où l'utilisation de _near et _far
*/

#include <GL/glew.h>

#include <cmath>
#include "OVec3.h"
#include "OVec4.h"


class OMat4
{
public:

    OMat4();
    OMat4(const float *value);
    OMat4(const OMat4& m4);
    ~OMat4();

    OMat4   operator * (const OMat4& m4) const;
    OMat4   operator + (const OMat4& m4) const;
    OMat4   operator - (const OMat4& m4) const;
    OMat4&  operator = (const OMat4& m4);

    OMat4   operator / (const float value) const;
    OMat4   operator * (const float value) const;
    OVec3_f operator * (const OVec3_f& v3) const;
    OVec4_f operator * (const OVec4_f& v4) const;

    void    operator += (const OMat4& m4);
	void    operator -= (const OMat4& m4);
	void    operator *= (const OMat4& m4);

    void    clear();

    float const* getFv() const;
    OMat4   getInverse() const;
    float   getValue(int idx) const;

	void	initRotateTransform(float x, float y, float z);
	void	initScaleTransform(float x, float y, float z);
	void	initTranslationTransform(float x, float y, float z);

    void    inverse();

    void    loadIdentity();
    void    lookAt(float eyeX, float eyeY, float eyeZ, float centerX, float centerY, float centerZ, float upX, float upY, float upZ);
    void    lookAt(OVec3_f& eye, OVec3_f& center, OVec3_f& up);

    void    ortho(float left, float bottom, float right, float top, float _near, float _far);
    void    ortho(float w, float h);
	void    ortho(int w, int h);

    void    perspective(float fovy, float aspect, float _near, float _far);
    void    perspective(float left, float right, float bottom,	float top, float _near, float _far);

    //GLboolean    pop();
    //GLboolean    push();

    void    rotate(float angle, float x, float y, float z);
    void    rotate(float angle, OVec3_f& axe);

    void    scale(float x, float y, float z);
    void    scale(const OVec3_f& v);
    void    scale(float xyz);
    void    setValue(int position, float value);

    void    translate(float x, float y, float z);
	void    translate(int x, int y, int z);
    void    translate(const OVec3_f& v);
    void    transpose();

private:

    float       m_value[16];
    //OMat4*      m_ptPile;
    //void        _depiler();
};

#endif

