#ifndef OTEXTURELIST_H_INCLUDED
#define OTEXTURELIST_H_INCLUDED

/*
OBJET       classe d'une liste de textures

DATE        12/2017

AUTEUR      philippe Thebaud

COMMENTAIRE
*/

#include <GL/glew.h>
#include <string>
#include <map>

#include "OUtils.h"
#include "OSurface.h"

enum {
    OTEXTURELIST_INTERFACE, OTEXTURELIST_MESH, OTEXTURELIST_EDGE, OTEXTURELIST_MIPMAP, OTEXTURELIST_MIP_MANUAL };

/*
fonction de chargement d'une texture >> devra être libérée manuellement !
if (texParam.id)
    glDeleteTextures(1,&texParam.id);
*/
s_texParam   ECO_loadTexture(std::string file, uint32_t filter = 0, bool useMipMap = false);



class OTextureList
{
public:
    OTextureList();
    ~OTextureList();

    //void        add(std::string name, std::string texture, GLfloat diff[4], GLfloat alpha);
    //void        add(SMaterial_eco& material);
    //void        add(SObjetPart_eco& material);
    void        add(std::string refTexture);
	void		add(std::string refTexture, float r, float g, float b, float a);

    void        clear();

    bool        del(std::string refTexture);
    bool        del(uint32_t refTextureID);

    uint32_t    getHeight(std::string refTexture);
    uint32_t    getWidth(std::string refTexture);
    uint32_t    getID(std::string refTexture);
    s_texParam  getParam(std::string refTexture);
    s_texParam  getParam(uint32_t index);
    std::string	getReference(uint32_t refId);
    //std::string getRefByIdx(uint32_t index);
    uint32_t	getSize();

    void        incCounter(uint32_t refTextureID);

    static void P_setFilter(uint32_t mode);
    static void P_setPath(const std::string path);
    static void P_setMipmap(bool mode);
    static std::string  P_getPath();

private:

    bool        _load(std::string refMap, OSurface& surface);
    void		_make(std::string refTexture, OSurface& surface);

private:

    typedef std::map<std::string, uint32_t> typeTexture;
    typeTexture m_texture;
    typeTexture m_height;
    typeTexture m_width;
	typeTexture	m_compteur; //à chaque reference de texture est associé un compteur

};


#endif // OTextureList_H_INCLUDED
