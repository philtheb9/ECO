
#include "OLoader.h"

static OTextureList textureList; //conteneur texture commun à tous les meshs

//static std::string	p_path = "donnees/mesh/";
//static bool         p_vao = true;
static bool         p_mipmap = false;
//static int          p_normal = 0; //null=0 smoth
static OVec3_f      p_scale(1.0f, 1.0f, 1.0f);
//static bool         p_error = false;
static int          p_filter = OTEXTURELIST_MESH;


// -----------------------
// --- le constructeur ---
// -----------------------

OLoader_obj::OLoader_obj()
{
    //
}

// ----------------------
// --- le destructeur ---
// ----------------------

OLoader_obj::~OLoader_obj()
{
    //
}

// --------------------
// --- les méthodes ---
// --------------------



bool OLoader_obj::load(std::string path, std::string file,
                       std::deque<Sobj_part>& objet, std::deque<Sobj_material>& material, std::vector<size_t>& bornage)
{
    std::ifstream flux;
    std::string code;
	float x,y,z;
	size_t refPart = 0;

	std::vector<OVec3_f> vertex;
	std::vector<OVec2_f> uv;
	std::vector<OVec3_f> normal;

	file = path + file;
    flux.open( file.c_str(), std::ios::in);
    if (!flux)
    {
        ECO_error_set("Impossible d'ouvrir : %s >OLoader_obj.load", file.c_str());
        return false;
    }
    //ECO_error_set("ok : %s >OLoader_obj.load", file.c_str());

    //index OBJ commence à 1 !
    vertex.push_back( OVec3_f(0,0,0) );
	uv.push_back( OVec2_f(0,0) );
	normal.push_back( OVec3_f(0,0,0) );

	// les textures sont dans le répertoire (pas sous répertoire)
    OTextureList::P_setPath(path);
    OTextureList::P_setFilter(p_filter);
    //OTextureList::P_setFilter(OTEXTURELIST_INTERFACE);
    OTextureList::P_setMipmap(p_mipmap);

    while( _readLine(flux) )
	{
        //lecture du code du fichier
        if (!(flux >> code))
            break; //erreur;

		//skip comments
		if (code == "#")
			continue;

		else if (code == "v")
		{
		    flux >> x >> y >> z;
		    //convertion des y up en z up de notre systeme
            vertex.push_back( OVec3_f(x * p_scale.x, -z * p_scale.y, y * p_scale.z) );
		}
		else if (code == "vn") //process vertex normal
		{
		    flux >> x >> y >> z;
            normal.push_back( OVec3_f(x,-z,y) );
		}
		else if (code == "vt") //process vertex texture
		{
            flux >> x >> y;
			uv.push_back( OVec2_f(x, y) );
		}
		else if (code == "f")
		{
            int v,t,n;

            // face à 3 (voire 99 !) vertices
            int i = 0;
            for (char c; i < 99; i++)
            {
                v = 0; t = 0; n = 0;
				//v uv n commencent à 1 !
				if (uv.size() == 1  && normal.size() == 1)
                    flux >> v;
                else if (uv.size() == 1)
                    flux >> v >> c >> c >> n;   // "//"
                else if (normal.size() == 1)
                    flux >> v >> c >> t;        // "/"
                else
                    flux >> v >> c >> t >> c >> n;
                if (!flux.good())
					break;
                //
                size_t idx = objet[refPart].sommet.size();
                objet[refPart].sommet.push_back( Sobj_sommet() );

                objet[refPart].sommet[idx].vertex = vertex[v];
                //
                //objet[refPart].sommet[idx].uv     = uv[t];
                objet[refPart].sommet[idx].uv.x   = uv[t].x * material[objet[refPart].material].tex_param.repeatX;
                objet[refPart].sommet[idx].uv.y   = uv[t].y * material[objet[refPart].material].tex_param.repeatY;
                //
                objet[refPart].sommet[idx].normal = normal[n] * material[objet[refPart].material].tex_param.multBump;

                objet[refPart].indice.push_back(idx);    // on affichera les faces selon l'ordre de chargement

            }
            objet[refPart].topologie.push_back(i);
		}
        // l'objet change de texture = nouveau objet / pas nouvel objet
		else if (code == "usemtl")
		{
		    std::string name;
		    bool error = true;

            std::getline(flux, name);
            name = ECO_trim(name);

            //index material -> material en cours = les faces seront ajoutées à cette partie
            refPart = objet.size();
            objet.push_back(Sobj_part());
            //objet[refPart].name = name;

            error = true;
            // associer le material
            for (size_t i = 0; i < material.size(); i++)
            {
                if (material[i].name == name)
                {
                    objet[refPart].material = i;
                    error = false;
                    //ECO_error_set("usemtl %s - %s", name.c_str(), material[i].map_diffuse.c_str());
                    break;
                }
            }
            if (error)
            {
                ECO_error_set("echec usemtl %s - %s >OLoader_obj.load_obj", name.c_str(), file.c_str());
            }
		}
		else if (code == "mtllib")
		{
		    std::string str;
            //flux >> str; // erreur sur les noms avec espace
            std::getline(flux, str);
            str = path + ECO_trim(str);
            if (!_load_mtl(str, material)) return false;
		}
		else if (code == "o")
        {
            // ce qui donnera la liste des objets (contenant n material) ex:  (0) 1 2 - (3) - (4) - (5) 6
            bornage.push_back(objet.size());
        }
		flux.clear();
	}

	for (size_t part = 0; part < objet.size(); part++)
    {
        objet[part].topologie_style = objet[part].topologie[0];
        for (size_t i = 1; i < objet[part].topologie.size(); i++)
        {
            if (objet[part].topologie[i] != objet[part].topologie_style)
            {
                objet[part].topologie_style = TOP_POLYGON;
                break;
            }
        }
    }
    /*
    certaines faces doivent etre découpées en triangle pour être visible
    *** bug sans explication
    */

	OTextureList::P_setMipmap(false);

	return true;
}


bool OLoader_obj::_load_mtl(std::string file, std::deque<Sobj_material>& material)
{
    std::string code, name;
	size_t refMaterial = 0;

    std::ifstream flux( file.c_str(), std::ios::in);
    if (!flux)
    {
        ECO_error_set("Impossible d'ouvrir : %s >OLoaderOBJ.loaderMTL", file.c_str());
        return false;
    }

    while( _readLine(flux) )
	{
        //lecture du code du fichier (les lignes vides sont passées)
        if (!(flux >> code))
            break; //erreur;

		//skip comments
		if (code == "#")
			continue;

		//start material
		else if (code == "newmtl")
		{
            std::string fileMaterial;

            flux >> fileMaterial;
            fileMaterial = ECO_trim(fileMaterial);

            refMaterial = material.size();
            material.push_back(Sobj_material());
            material[refMaterial].name = fileMaterial;
		}
		else if ( code == "Kd") //diffuse
		{
            flux >> material[refMaterial].Kd[0] >> material[refMaterial].Kd[1] >> material[refMaterial].Kd[2];
		}
		else if ( code == "Ks")  //specular
		{
            flux >> material[refMaterial].Ks[0] >> material[refMaterial].Ks[1] >> material[refMaterial].Ks[2];
		}
        else if ( code == "Ke")  //emissive
		{
		    flux >> material[refMaterial].Ke[0] >> material[refMaterial].Ke[1] >> material[refMaterial].Ke[2];
		}
		else if ( code == "Ns")  //shiny
        {
		    float n;
		    flux >> n;
		    material[refMaterial].Ns = n;
		}
		else if ( code == "d")   //transparent
        {
            float d;
		    flux >> d;
		    material[refMaterial].alpha = d;
        }
		else if (code == "map_Kd")
		{
            std::string str;
            //flux >> str;
            std::getline(flux, str); //il faut lire le reste de la ligne avec les paramètres
            str = ECO_trim(str);
            //
            material[refMaterial].map_diffuse = str;
		}
		// mtl note bump et non map_Bump ? -> j'utilise la méthode de blender
        else if (code == "map_Bump")
		{
            std::string str;
            //flux >> str;
            std::getline(flux, str); //il faut lire le reste de la ligne avec les paramètres
            str = ECO_trim(str);
            //
            material[refMaterial].map_bump = str;
		}
        else if (code == "map_Ks")
		{
            std::string str;
            //flux >> str;
            std::getline(flux, str); //il faut lire le reste de la ligne avec les paramètres
            str = ECO_trim(str);
            //
            material[refMaterial].map_specular = str;
		}
        else if (code == "map_d")
		{
		    // on ne respecte pas la méthode MTL
		    // on procedera à un cliping des partie alpha = 0
            material[refMaterial].clip = true;
            flux.clear();
		}
		//else if (code == "illum")
        //{
        //    flux >> material[refMaterial].illum;
        //}
        else
		{
			//code non prit en charge
			_skipLine(flux);
		}
		flux.clear();
	}

	flux.close();

	// --- composition de base

	for (size_t i = 0; i < material.size(); i++)
    {
        if (material[i].map_diffuse == "")
        {
            float r,g,b;

            name = material[i].name;
            //ECO_error_set("texture : %s", name.c_str());
            //if (material[i].illum == 1)
            //{
            //    r = material[i].Kd[0];
            //    g = material[i].Kd[1];
            //    b = material[i].Kd[2];
            //}
            //else
            //{

            // illum 2 ! simulation de la lumière phong (-0.025f renforce les couleurs)
            r = sqrt( material[i].Kd[0] * 100.0f) * 0.1f;
            g = sqrt( material[i].Kd[1] * 100.0f) * 0.1f;
            b = sqrt( material[i].Kd[2] * 100.0f) * 0.1f;

            textureList.add(name, r,g,b, 1.0f);
            material[i].tex_color = textureList.getID(name);
        }
        else
        {
            Sobj_param param;
            _getParam(material[i].map_diffuse, param);
            // attention = nom image sert de reference = si deux images même nom dans deux répertoire = une seule chargée
            //ECO_error_set("Oloader.load_mtl > %s", param.image.c_str());
            material[i].tex_param = param;

            textureList.add(param.image);
            material[i].tex_color = textureList.getID(param.image);
        }

        // texture bump de base qui remplacera les textures non chargées
        if (material[i].map_bump == "")
        {
            name = "normal_map";
            textureList.add(name, 0.5f, 0.5f, 1.0f, 1.0f);
            material[i].tex_bump = textureList.getID(name);
        }
        else
        {
            Sobj_param param;
            _getParam(material[i].map_bump, param);

            textureList.add(param.image);
            material[i].tex_bump = textureList.getID(param.image);
        }

        // texture specular de base qui remplacera les textures non chargées
        if (material[i].map_specular == "")
        {
            name = material[i].name + "_s";
            textureList.add(name, material[i].Ks[0], material[i].Ks[1], material[i].Ks[2], material[i].Ks[0]);
            material[i].tex_specular = textureList.getID(name);
        }
        else
        {
            textureList.add(material[i].map_specular);
            material[i].tex_specular = textureList.getID(material[i].map_specular);
        }
    }

	return true;
}

void OLoader_obj::_getParam(std::string strParam, Sobj_param& param)
{
    std::vector<std::string> strList;
    size_t i = 0;

    param.repeatX = 1.0f;
    param.repeatY = 1.0f;
    param.repeatZ = 1.0f;
    param.offsetX = 0.0f;
    param.offsetY = 0.0f;
    param.offsetZ = 0.0f;
    param.gain0 = 0;
    param.gain1 = 0;
    param.multBump = 1.0f;
    param.image = strParam;

    ECO_strCut(strList,strParam,' ');

    while(i < strList.size())
    {
        if (strList[i] == "-s")
        {
            param.repeatX = ECO_strToFloat(strList[i+1]);
            param.repeatY = ECO_strToFloat(strList[i+2]);
            param.repeatZ = ECO_strToFloat(strList[i+3]);
            i+=3;
        }
        else
        if (strList[i] == "-o")
        {
            param.offsetX = ECO_strToFloat(strList[i+1]);
            param.offsetY = ECO_strToFloat(strList[i+2]);
            param.offsetZ = ECO_strToFloat(strList[i+3]);
            i+=3;
        }
        else
        if (strList[i] == "-mm")
        {
            param.gain0 = ECO_strToInt(strList[i+1]);
            param.gain1 = ECO_strToInt(strList[i+2]);
            i+=2;
        }
        else
        if (strList[i] == "-bm")
        {
            param.multBump = ECO_strToInt(strList[i+1]);
            i+=1;
        }
        i++;
    }
    if (strList.size() > 0)
    {
        param.image = strList[strList.size()-1];
    }
}

bool OLoader_obj::_readLine(std::istream& flux)
{
	char next;
	while( flux >> std::skipws >> next )
    {
		flux.putback(next);
		if ('#' == next)
			_skipLine(flux);
		else
			return true;
    }

    return false;
}

/*
passe la ligne du fichier OBJ
*/
void OLoader_obj::_skipLine(std::istream& flux)
{
    char next;
	flux >> std::noskipws;
    while( (flux >> next) && ('\n' != next) );
}



void OLoader_obj::P_setMipmap(bool mode)
{
    p_mipmap = mode;
}

void OLoader_obj::P_setScale(float x, float y, float z)
{
    p_scale.set(x,y,z);
}

// efface la texture / decompte si elle est utilisée plusieurs fois = efface si zéro
void OLoader_obj::P_clear_texture(std::deque<Sobj_material>& material)
{
    for (size_t i = 0; i < material.size(); i++)
    {
        textureList.del( material[i].tex_color );
        textureList.del( material[i].tex_bump );
        textureList.del( material[i].tex_specular );
    }
}
void OLoader_obj::P_setFilter(int filter)
{
    p_filter = filter;
}





