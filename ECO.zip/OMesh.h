
#ifndef OMESH_H_INCLUDED
#define OMESH_H_INCLUDED

/*
OBJET       classe d'un objet 3d

DATE        12/2019

AUTEUR      philippe Thebaud

COMMENTAIRE load obj uniquement
*/

#include <GL/glew.h>
#include <string>
#include <vector>
#include <deque>
//#include <cstring> //memcopy pour VBO
#include <iostream>

#include "OUtils.h"
//#include "OTextureList.h"
#include "OLoader.h"

// structures dans Oloader


class OMesh
{
public:

	OMesh();
    ~OMesh();

    void        clear();
    bool        create(std::string file);

    void        draw();
    void        draw(size_t part);

    void        draw_line();
    void        draw_line(size_t part);
    void        draw_no_texture();
    //void        draw_color();
    //void        draw_color(size_t part);

    //void        draw_vi(size_t part);
    void        draw_multi_color(size_t part);
    void        draw_multi_line(size_t part);
    void        draw_multi(size_t part);
    void        end_draw_part();

    float       getAlpha(size_t part);
    void        getBound(OVec3_f& bound_min, OVec3_f& bound_max);
    uint32_t    getBumpMap(size_t part);
    float       getScaleNormal(size_t part);
    bool        getClip(size_t part);
    uint32_t    getColorMap(size_t part);
    OVec4_f     getDiffuse(size_t part);
    uint32_t    getSpecularMap(size_t part);

	size_t      getNbPart();

	void        setModelMulti(std::vector<OMat4>& modelMulti);

	static void P_setMipmap(bool mode);
    static void P_setPath(std::string path);
	static void P_setScale(float sx, float sy, float sz);
	static void P_setScale(OVec3_f& scale);
	static void P_setVao(bool mode);

private:

    //void        _getParam(std::string strParam, Sobj_param& param);

    //bool        _load_obj();
    //bool        _load_mtl(std::string file);

    void        _make_vao();
    void        _make_vi();
    void        _make_vao_multi();

    //bool        _readLine(std::istream& flux);
    //void        _skipLine(std::istream& flux);

private:

    std::vector<size_t>         bornage;
    std::deque<Sobj_material>   material;

    std::deque<Sobj_part>       objet;

	std::string	m_path, m_file;
    size_t      m_numInstances;

};

#endif
