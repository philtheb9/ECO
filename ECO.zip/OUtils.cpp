#include "OUtils.h"


// ------------------------------------------
// fonctions de paramétrage de l'écran openGL
// ------------------------------------------
static int eco_gl_viewPortW = 0, eco_gl_viewPortH = 0;

//x et y à zéro par défaut
void ECO_setViewPort(int w, int h, int x, int y)
{
	eco_gl_viewPortW = w;
	eco_gl_viewPortH = h;
    glViewport(x, y, w, h);
}

int ECO_getViewPortW()
{
	return eco_gl_viewPortW;
}

int ECO_getViewPortH()
{
	return eco_gl_viewPortH;
}


OVec2_i ECO_point3dTo2d(OMat4& vp, OVec3_f& pos, int hw, int hh)
{
	OVec2_i result;
    OVec4_f screenPos, v4;
    //int hw = ECO_getViewPortW() / 2;
    //int hh = ECO_getViewPortH() / 2;

    // perspective
    //view.loadIdentity();
    //camera.lookAt(view);
    //vp = m_proj3d * view; // * _perso->getModel();

    v4.set(pos.x, pos.y, pos.z, 1.0f);

	//screenPos.x = vp.getValue(0) * v4.x + vp.getValue(4) * v4.y + vp.getValue(8)  * v4.z + vp.getValue(12) * v4.w;
	//screenPos.y = vp.getValue(1) * v4.x + vp.getValue(5) * v4.y + vp.getValue(9)  * v4.z + vp.getValue(13) * v4.w;
	//screenPos.z = vp.getValue(2) * v4.x + vp.getValue(6) * v4.y + vp.getValue(10) * v4.z + vp.getValue(14) * v4.w;
	//screenPos.w = vp.getValue(3) * v4.x + vp.getValue(7) * v4.y + vp.getValue(11) * v4.z + vp.getValue(15) * v4.w;

    //mat4 "horizontale"
    screenPos.x = vp.getValue(0)  * v4.x + vp.getValue(1)  * v4.y + vp.getValue(2)  * v4.z + vp.getValue(3)  * v4.w;
	screenPos.y = vp.getValue(4)  * v4.x + vp.getValue(5)  * v4.y + vp.getValue(6)  * v4.z + vp.getValue(7)  * v4.w;
	screenPos.z = vp.getValue(8)  * v4.x + vp.getValue(9)  * v4.y + vp.getValue(10) * v4.z + vp.getValue(11) * v4.w;
	screenPos.w = vp.getValue(12) * v4.x + vp.getValue(13) * v4.y + vp.getValue(14) * v4.z + vp.getValue(15) * v4.w;

	if (screenPos.w < 0.1f)
    {
        result.set(-1000, -1000);
        return result; // sinon le pos éloigné revient dans l'écran
    }
    screenPos.x /= screenPos.w;
    screenPos.y /= screenPos.w;

    result.x = (screenPos.x * hw) + hw;
    result.y = (screenPos.y * hh) + hh;

	return result;
}


// -------------------------------------------------
// fonctions assurant une sortie fichier des erreurs
// -------------------------------------------------

static bool eco_gl_error_write = true;

void ECO_error_set(const char *format, ...)
{
	static bool exist = false;

	if (!eco_gl_error_write)
		return;
    // elimine le précédent fichier (compilation précédente)
	if (!exist)
		remove("bin/errors.txt");

	va_list argList;
	va_start(argList, format);

	//int length = vprintf(format, argList);
	//char* msg = new char[length+32];	//+32 = reservation de place pour les nombres
	char* msg = new char[512];
	vsprintf(msg, format, argList);
	strcat(msg, "\n");

    FILE* fichier = NULL;
    fichier = fopen("bin/errors.txt", "a");
    //ajout
    if (fichier != NULL)
    {
        fprintf(fichier, msg);
    }
	fclose(fichier);

	exist = true;
	delete [] msg;
}

void ECO_error_write(bool write)
{
	//active desactive l'écriture des msg
	eco_gl_error_write = write;
}

// -----------------------------
// fonction pointant sur un objet
// permettant de lui donner ou récuper le focus
// ------------------------------

static void *eco_gl_ptObjet = NULL;

void* ECO_getFocus()
{
    return eco_gl_ptObjet;
}

void ECO_setFocus(void *pointeurSurObjet)
{
    eco_gl_ptObjet = pointeurSurObjet;
}

