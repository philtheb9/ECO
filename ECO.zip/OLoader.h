
#ifndef OLOADER_H_INCLUDED
#define OLOADER_H_INCLUDED

/*
OBJET       chargeur d'objets 3d

DATE        12/2019

AUTEUR      philippe Thebaud

COMMENTAIRE load obj uniquement
*/

#include <GL/glew.h>
#include <string>
#include <vector>
#include <deque>
//#include <cstring> //memcopy pour VBO
#include <iostream>

#include "../ECO/OUtils.h"
#include "../ECO/OTextureList.h"



struct Sobj_param
{
    float       repeatX,repeatY,repeatZ;
    float       offsetX,offsetY,offsetZ;
    int         gain0,gain1;
    float       multBump;
    std::string image;

    Sobj_param()
    {
        repeatX = 1.0f; repeatY = 1.0f; repeatZ = 1.0f;
        offsetX = 0.0f; offsetY = 0.0f; offsetZ = 0.0f;
        gain0 = 0; gain1 = 0;
        multBump = 1.0f;
        image = "";
    }
    void clear()
    {
        repeatX = 1.0f; repeatY = 1.0f; repeatZ = 1.0f;
        offsetX = 0.0f; offsetY = 0.0f; offsetZ = 0.0f;
        gain0 = 0; gain1 = 0;
        multBump = 1.0f;
        image = "";
    }
};

struct Sobj_material
{
    std::string name;       // reference
    float       Ns;         // shiny multiplicateur de specular mode WarlIso dans blender
    float       Kd[4];      // diffuse color = red green blue alpha
    float	    Ks[4];	    // specular color
    float       Ke[4];      // emissive
    float       alpha;	    // opacitée
    //int         illum;      // mode eclairage 1 ou 2 (par default)
    bool        clip;       // si la texture doit etre utilisée avec un clip = non écriture des données alpha = 0
    Sobj_param  tex_param;
    // textures (dans l'ordre)
    std::string	map_diffuse, map_bump, map_specular;
    uint32_t    tex_color, tex_bump, tex_specular;

    Sobj_material() { clear(); }
    void clear()
    {
        name = "";
        Ns = 0.0f;
        Kd[0] = Kd[1] = Kd[2] = 0.8f; Kd[3] = 1.0f;
        Ks[0] = Ks[1] = Ks[2] = 0.0f; Ks[3] = 1.0f;
        Ke[0] = Ke[1] = Ke[2] = 0.0f; Ke[3] = 1.0f;
        alpha = 1.0f;
        //illum = 2;
        tex_param.clear();
        map_diffuse = ""; map_bump = ""; map_specular = "";
        tex_color = 0; tex_bump = 0; tex_specular = 0;
        clip = false;
    }
};

struct Sobj_sommet
{
    OVec3_f     vertex;
    OVec2_f     uv;
    OVec3_f     normal;

    Sobj_sommet() {}

    Sobj_sommet(const OVec3_f& vertex0, const OVec2_f& uv0, const OVec3_f& normal0)
    {
        vertex  = vertex0;
        uv      = uv0;
        normal  = normal0;
    }
};

enum {BUF_VERTEX, BUF_UV, BUF_NORMAL, BUF_MODEL};
//topologie
enum {TOP_TRIANGLE=3, TOP_QUAD, TOP_POLYGON};

struct Sobj_part
{
    uint32_t    material;
    uint32_t    vertexBuffer, indexBuffer;
    uint32_t    vao, buffer[4];

    std::vector<Sobj_sommet>    sommet;
    std::vector<uint32_t>       indice;
    std::vector<uint32_t>       topologie;
    uint32_t                    topologie_style; // 3=GL_TRIANGLES, 4=GL_QUADS, 5=GL_POLYGON

    Sobj_part()
    {
        material = 0;
        vertexBuffer = 0; indexBuffer = 0;
        vao = 0, buffer[0] = 0, buffer[1] = 0; buffer[2] = 0; buffer[3] = 0;
        sommet.clear();
        indice.clear();
        topologie.clear();
    }
};




class OLoader_obj
{
public:
	OLoader_obj();
    ~OLoader_obj();

    bool        load(std::string path, std::string file,
                     std::deque<Sobj_part>& objet, std::deque<Sobj_material>& material, std::vector<size_t>& bornage);

    static void P_clear_texture(std::deque<Sobj_material>& material);
    static void P_setMipmap(bool mode);
    static void P_setScale(float x, float y, float z);
    static void P_setFilter(int filter);

private:

    void        _getParam(std::string strParam, Sobj_param& param);

    bool        _load_mtl(std::string file, std::deque<Sobj_material>& material);

    bool        _readLine(std::istream& flux);

    void        _skipLine(std::istream& flux);

};



#endif
