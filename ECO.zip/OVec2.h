#ifndef OVEC2_H_INCLUDED
#define OVEC2_H_INCLUDED

/*
OBJET       classe d'un vec2

DATE        12/2017

AUTEUR      philippe Thebaud

COMMENTAIRE
*/

#include <cmath>
#include <GL/glew.h>
#include <GL/wglew.h>

//les structures statiques
struct SVec2_i { int x; int y; };
struct SVec2_f { float x; float y; };


template <class T> class OVec2
{
public:
    T x, y;

    OVec2() {x=0;y=0;};
    OVec2(const T vx, const T vy) { x=vx; y=vy; };


    void    set(const T vx, const T vy)
    {
        x = vx;
        y = vy;
    }
    void    set(const T v[2])
    {
        x = v[0];
        y = v[1];
    }



    bool operator == (const OVec2& v2) const
    {
        return (x == v2.x && y == v2.y);
    }
    bool operator != (const OVec2& v2) const
    {
        return (x != v2.x || y != v2.y);
    }
    bool operator <= (const OVec2& v2) const
    {
        return (x <= v2.x && y <= v2.y);
    }
    bool operator >= (const OVec2& v2) const
    {
        return (x >= v2.x && y >= v2.y);
    }



    OVec2& operator = (const OVec2& v2)
    {
        x = v2.x;
        y = v2.y;
        return(*this);
    }
    // pour transfert des donnees
    OVec2& operator = (const SVec2_f& v2)
    {
        x = v2.x;
        y = v2.y;
        return(*this);
    }
    OVec2& operator = (const SVec2_i& v2)
    {
        x = v2.x;
        y = v2.y;
        return(*this);
    }

    OVec2 operator + (const OVec2& v2) const
    {
        OVec2 result(x+v2.x, y+v2.y);
        return result;
    }
    OVec2 operator - (const OVec2& v2) const
    {
        OVec2 result(x-v2.x, y-v2.y);
        return result;
    }
    OVec2 operator * (const OVec2& v2) const
    {
        OVec2 result(x*v2.x, y*v2.y);
        return result;
    }
    OVec2 operator / (const OVec2& v2) const
    {
        OVec2 result(0,0);
        if (v2.x*v2.y == 0) return result;
        result.set(x/v2.x, y/v2.y);
        return result;
    }


    OVec2 operator * (const T value) const
    {
        OVec2 result(x*value, y*value);
        return result;
    }
    OVec2 operator / (const T value) const
    {
        OVec2 result(0,0);
        if (value == 0) return result;
        result.set(x/value, y/value);
        return result;
    }
    OVec2 operator + (const T value) const
    {
        OVec2 result(x+value, y+value);
        return result;
    }
    OVec2 operator - (const T value) const
    {
        OVec2 result(x-value, y-value);
        return result;
    }

    OVec2& operator += (const OVec2& v2)
    {
        x += v2.x;
        y += v2.y;
        return *this;
    }
    OVec2& operator -= (const OVec2& v2)
    {
        x -= v2.x;
        y -= v2.y;
        return *this;
    }
    OVec2& operator *= (const T value)
    {
        x *= value;
        y *= value;
        return *this;
    }
    OVec2& operator /= (const T value)
    {
        if(value == 0) return OVec2(0,0);
        x /= value;
        y /= value;
        return *this;
    }



    T   length() const
    {
        return ((T)sqrt(x*x+y*y));
    }

    T   lengthSqr() const
    {
        return (x*x+y*y);
    }

    T   dot(const OVec2& v0, const OVec2& v1) const
    {
        return v0.x*v1.x + v0.y*v1.y;
    }

    void normalize()
    {
        T lg = sqrtf(x*x + y*y);
        if (lg > 0)
        {
            const T a = 1.0 / lg; //1 seule division lente
            x *= a;
            y *= a;
        }
    }
    OVec2 normalized() const
    {
        OVec2 result(*this);
        result.normalize();
        return result;
    }

};

typedef OVec2<float>  OVec2_f;
typedef OVec2<double> OVec2_d;
typedef OVec2<int>    OVec2_i;

#endif
